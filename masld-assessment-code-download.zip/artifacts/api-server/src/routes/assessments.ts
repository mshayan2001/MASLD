import { Router, type IRouter } from "express";
import { desc, eq } from "drizzle-orm";
import { db, assessmentsTable } from "@workspace/db";
import {
  CreateAssessmentBody,
  GetAssessmentParams,
  DeleteAssessmentParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/assessments/stats", async (req, res): Promise<void> => {
  const rows = await db.select().from(assessmentsTable);

  const byClassification: Record<string, number> = {};
  const byFib4Risk: Record<string, number> = {};
  let fib4Sum = 0;
  let fib4Count = 0;
  let ageSum = 0;
  let bmiSum = 0;

  for (const row of rows) {
    const results = row.results as any;
    const cls = results?.sldClassification ?? "unknown";
    byClassification[cls] = (byClassification[cls] ?? 0) + 1;

    const fib4Risk = results?.fib4Risk ?? "unavailable";
    byFib4Risk[fib4Risk] = (byFib4Risk[fib4Risk] ?? 0) + 1;

    if (results?.fib4Score != null) {
      fib4Sum += Number(results.fib4Score);
      fib4Count++;
    }
    ageSum += row.age;
    bmiSum += Number(row.bmi);
  }

  res.json({
    totalAssessments: rows.length,
    byClassification,
    byFib4Risk,
    avgFib4Score: fib4Count > 0 ? Math.round((fib4Sum / fib4Count) * 100) / 100 : null,
    avgAge: rows.length > 0 ? Math.round((ageSum / rows.length) * 10) / 10 : null,
    avgBmi: rows.length > 0 ? Math.round((bmiSum / rows.length) * 10) / 10 : null,
  });
});

router.get("/assessments", async (req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(assessmentsTable)
    .orderBy(desc(assessmentsTable.createdAt));

  res.json(
    rows.map((r) => ({
      ...r,
      bmi: Number(r.bmi),
      waistCircumferenceCm: r.waistCircumferenceCm != null ? Number(r.waistCircumferenceCm) : null,
      alcoholGramsPerDay: Number(r.alcoholGramsPerDay),
      createdAt: r.createdAt.toISOString(),
    }))
  );
});

router.post("/assessments", async (req, res): Promise<void> => {
  const parsed = CreateAssessmentBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid assessment body");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;

  const [row] = await db
    .insert(assessmentsTable)
    .values({
      patientName: data.patientName,
      age: data.age,
      sex: data.sex,
      ethnicity: data.ethnicity ?? null,
      bmi: String(data.bmi),
      waistCircumferenceCm: data.waistCircumferenceCm != null ? String(data.waistCircumferenceCm) : null,
      hasHepaticSteatosis: data.hasHepaticSteatosis,
      alcoholGramsPerDay: String(data.alcoholGramsPerDay),
      notes: data.notes ?? null,
      cardiometabolicFactors: data.cardiometabolicFactors as any,
      labValues: data.labValues as any,
      imagingResults: data.imagingResults as any,
      secondaryCauses: (data.secondaryCauses ?? {}) as any,
      hepatotoxicMedications: (data.hepatotoxicMedications ?? {}) as any,
      results: data.results as any,
    })
    .returning();

  res.status(201).json({
    ...row,
    bmi: Number(row.bmi),
    waistCircumferenceCm: row.waistCircumferenceCm != null ? Number(row.waistCircumferenceCm) : null,
    alcoholGramsPerDay: Number(row.alcoholGramsPerDay),
    createdAt: row.createdAt.toISOString(),
  });
});

router.get("/assessments/:id", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const [row] = await db
    .select()
    .from(assessmentsTable)
    .where(eq(assessmentsTable.id, id));

  if (!row) {
    res.status(404).json({ error: "Assessment not found" });
    return;
  }

  res.json({
    ...row,
    bmi: Number(row.bmi),
    waistCircumferenceCm: row.waistCircumferenceCm != null ? Number(row.waistCircumferenceCm) : null,
    alcoholGramsPerDay: Number(row.alcoholGramsPerDay),
    createdAt: row.createdAt.toISOString(),
  });
});

router.delete("/assessments/:id", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const [row] = await db
    .delete(assessmentsTable)
    .where(eq(assessmentsTable.id, id))
    .returning();

  if (!row) {
    res.status(404).json({ error: "Assessment not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
