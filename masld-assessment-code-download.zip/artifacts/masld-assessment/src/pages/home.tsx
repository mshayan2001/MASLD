import { useListAssessments, useGetAssessmentStats } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { PlusCircle, Activity, Users, AlertTriangle, ChevronRight, CheckCircle2, FileText, ClipboardList } from "lucide-react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function Home() {
  const { data: assessments, isLoading: loadingAssessments } = useListAssessments();
  const { data: stats, isLoading: loadingStats } = useGetAssessmentStats();

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground">Overview of MASLD clinical assessments</p>
          </div>
          <Link href="/assessment/new" className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-10 px-4 py-2 gap-2">
            <PlusCircle className="h-4 w-4" />
            Start New Assessment
          </Link>
        </div>

        {loadingStats ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 animate-pulse">
            {[1, 2, 3, 4].map(i => (
              <Card key={i}><CardHeader className="h-24"></CardHeader></Card>
            ))}
          </div>
        ) : stats ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Assessments</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalAssessments}</div>
                <p className="text-xs text-muted-foreground">Patients evaluated</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">MASLD Cases</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.byClassification?.['MASLD'] || 0}</div>
                <p className="text-xs text-muted-foreground">Diagnosed cases</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">High FIB-4 Risk</CardTitle>
                <AlertTriangle className="h-4 w-4 text-destructive" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-destructive">{stats.byFib4Risk?.['high'] || 0}</div>
                <p className="text-xs text-muted-foreground">Patients requiring attention</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg FIB-4 Score</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.avgFib4Score?.toFixed(2) || 'N/A'}</div>
                <p className="text-xs text-muted-foreground">Across all patients</p>
              </CardContent>
            </Card>
          </div>
        ) : null}

        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Assessments</CardTitle>
            <CardDescription>A list of the most recent patient evaluations.</CardDescription>
          </CardHeader>
          <CardContent>
            {loadingAssessments ? (
              <div className="space-y-4 animate-pulse">
                {[1, 2, 3].map(i => <div key={i} className="h-16 bg-muted rounded-md" />)}
              </div>
            ) : assessments && assessments.length > 0 ? (
              <div className="space-y-4">
                {assessments.map(assessment => (
                  <Link href={`/assessment/${assessment.id}`} key={assessment.id}>
                    <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer group">
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                          {assessment.patientName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-sm font-medium leading-none">{assessment.patientName}</p>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(assessment.createdAt), "MMM d, yyyy")} &bull; {assessment.age}y {assessment.sex}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant={assessment.results.sldClassification === 'NoSLD' ? 'outline' : 'default'} className="hidden md:inline-flex">
                          {assessment.results.sldClassification}
                        </Badge>
                        <Badge variant={assessment.results.fib4Risk === 'high' ? 'destructive' : assessment.results.fib4Risk === 'indeterminate' ? 'secondary' : 'outline'}>
                          FIB-4: {assessment.results.fib4Risk}
                        </Badge>
                        <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-foreground transition-colors" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <ClipboardList className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-lg font-medium">No assessments found</h3>
                <p className="text-sm text-muted-foreground mt-2 max-w-sm mb-6">
                  There are currently no patient assessments in the system. Start a new assessment to see it listed here.
                </p>
                <Link href="/assessment/new" className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-10 px-4 py-2 gap-2">
                  <PlusCircle className="h-4 w-4" />
                  Start New Assessment
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
