import { useGetAssessment, getGetAssessmentQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { useParams, Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Printer,
  ArrowLeft,
  Activity,
  HeartPulse,
  FlaskConical,
  ClipboardList,
  UserRound,
  TriangleAlert,
  CheckCircle2,
  Dot,
  Stethoscope,
  Scissors,
  Microscope,
  Pill,
} from "lucide-react";
import { format } from "date-fns";

const URGENCY_STYLES: Record<string, string> = {
  urgent:   "bg-red-50 text-red-800 border-red-200",
  moderate: "bg-amber-50 text-amber-800 border-amber-200",
  routine:  "bg-emerald-50 text-emerald-800 border-emerald-200",
};

const RISK_BADGE: Record<string, string> = {
  low:           "bg-emerald-100 text-emerald-800 border-emerald-200",
  indeterminate: "bg-amber-100 text-amber-800 border-amber-200",
  high:          "bg-red-100 text-red-800 border-red-200",
  unavailable:   "bg-muted text-muted-foreground",
};

const SLD_DESCRIPTIONS: Record<string, string> = {
  MASLD: "Metabolic dysfunction-associated steatotic liver disease — hepatic steatosis with ≥1 cardiometabolic risk factor and alcohol within safe limits.",
  MASH: "Metabolic dysfunction-associated steatohepatitis — MASLD with histological ballooning and lobular inflammation, indicating active hepatic injury and higher fibrosis risk.",
  MetALD: "MetALD — hepatic steatosis with ≥1 cardiometabolic risk factor AND moderate alcohol consumption (20-50 g/day women, 30-60 g/day men). Both metabolic and alcohol pathways are active.",
  ALD: "Alcohol-related liver disease — hepatic steatosis primarily driven by excess alcohol (>50 g/day women, >60 g/day men). Cessation is the single most effective treatment.",
  OtherSLD: "Specific Cause SLD (SC-SLD / DI-SLD) — steatosis attributable to a secondary condition (endocrine, metabolic, genetic) or a known hepatotoxic drug without primary metabolic or alcohol excess. Treating the underlying cause is the primary intervention.",
  CryptogenicSLD: "Cryptogenic steatotic liver disease — steatosis present without identifiable cardiometabolic, alcohol, drug-induced, or specific cause. Consider rare monogenic disorders; liver biopsy may be required.",
  NoSLD: "No steatotic liver disease — hepatic steatosis not confirmed. No SLD classification applies.",
};

const ETHNICITY_LABELS: Record<string, string> = {
  caucasian: "Caucasian / European",
  asian: "Asian",
  african: "African / Afro-Caribbean",
  hispanic: "Hispanic / Latin American",
  other: "Other",
};

export default function AssessmentResults() {
  const params = useParams();
  const id = params.id ? parseInt(params.id, 10) : 0;

  const { data: assessment, isLoading, error } = useGetAssessment(id, {
    query: { enabled: !!id, queryKey: getGetAssessmentQueryKey(id) },
  });

  if (isLoading) {
    return (
      <Layout>
        <div className="flex flex-col gap-6 animate-pulse max-w-5xl mx-auto">
          <div className="h-10 w-1/3 bg-muted rounded" />
          <div className="grid md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-4">
              <div className="h-48 bg-muted rounded" />
              <div className="h-64 bg-muted rounded" />
              <div className="h-64 bg-muted rounded" />
            </div>
            <div className="h-96 bg-muted rounded" />
          </div>
        </div>
      </Layout>
    );
  }

  if (error || !assessment) {
    return (
      <Layout>
        <div className="text-center py-20">
          <TriangleAlert className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Assessment Not Found</h2>
          <p className="text-muted-foreground mb-6">This assessment does not exist or could not be loaded.</p>
          <Link href="/">
            <Button><ArrowLeft className="mr-2 h-4 w-4" /> Return to Dashboard</Button>
          </Link>
        </div>
      </Layout>
    );
  }

  const { results } = assessment;
  const treatmentPlan = results.treatmentPlan;
  const urgencyStyle = URGENCY_STYLES[treatmentPlan.urgencyLevel] ?? URGENCY_STYLES.routine;
  const fib4RiskStyle = RISK_BADGE[results.fib4Risk] ?? RISK_BADGE.unavailable;
  const elastoRiskStyle = results.elastographyRisk
    ? RISK_BADGE[results.elastographyRisk] ?? RISK_BADGE.unavailable
    : null;

  // Secondary causes for display
  const sc = assessment.secondaryCauses;
  const activeSecondaryCauses = [
    sc.hasHypothyroidism && "Hypothyroidism",
    sc.hasPcos && "PCOS",
    sc.hasHypopituitarism && "Hypopituitarism",
    sc.hasCushingsSyndrome && "Cushing's Syndrome",
    sc.hasCoeliaceDisease && "Coeliac Disease",
    sc.hasObstructiveSleepApnoea && "OSA",
    sc.hasLipodystrophy && "Lipodystrophy",
    sc.hasWilsonsDisease && "Wilson's Disease",
    sc.hasTotalParenteralNutrition && "TPN-related",
    sc.hasRapidWeightLoss && "Rapid Weight Loss",
  ].filter(Boolean) as string[];

  return (
    <Layout>
      <div className="max-w-5xl mx-auto flex flex-col gap-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <Link
              href="/"
              className="text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center mb-2"
            >
              <ArrowLeft className="h-3 w-3 mr-1" /> Dashboard
            </Link>
            <h1 className="text-3xl font-bold tracking-tight">Assessment Results</h1>
            <p className="text-muted-foreground mt-1">
              <span className="font-medium text-foreground">{assessment.patientName}</span>
              {" "}&bull;{" "}
              {assessment.age} yrs{results.isPediatric && " (Paediatric)"}, {assessment.sex === "male" ? "Male" : "Female"}, BMI {assessment.bmi}
              {" "}&bull; Evaluated {format(new Date(assessment.createdAt), "d MMM yyyy")}
            </p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Badge
              variant="outline"
              className={`px-3 py-1.5 font-semibold uppercase text-xs ${urgencyStyle}`}
              data-testid="badge-urgency"
            >
              {treatmentPlan.urgencyLevel === "urgent" && <TriangleAlert className="h-3 w-3 mr-1 inline" />}
              {treatmentPlan.urgencyLevel} priority
            </Badge>
            <Button variant="outline" size="sm" onClick={() => window.print()}>
              <Printer className="mr-2 h-4 w-4" /> Print
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* ── Left: Clinical analysis + treatment ── */}
          <div className="md:col-span-2 space-y-5">

            {/* Clinical Classification */}
            <Card className="border-primary/30 shadow-sm">
              <CardHeader className="bg-primary/5 border-b pb-4">
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="h-4 w-4 text-primary" />
                  Clinical Classification
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-5 space-y-5">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">SLD Phenotype</p>
                    <p className="text-2xl font-bold text-primary mb-2" data-testid="text-sld-classification">
                      {results.hasMASH ? "MASH" : results.sldClassification}
                    </p>
                    <div className="flex flex-wrap gap-1.5 mb-2">
                      {results.hasMASH && (
                        <Badge className="bg-amber-100 text-amber-800 border-amber-200 text-xs">Steatohepatitis confirmed</Badge>
                      )}
                      {results.hasCirchosis && (
                        <Badge className="bg-red-100 text-red-800 border-red-200 text-xs">Cirrhosis</Badge>
                      )}
                      {results.isLeanMasld && (
                        <Badge className="bg-sky-100 text-sky-800 border-sky-200 text-xs">Lean MASLD</Badge>
                      )}
                      {results.isPediatric && (
                        <Badge className="bg-violet-100 text-violet-800 border-violet-200 text-xs">Paediatric</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {SLD_DESCRIPTIONS[results.hasMASH ? "MASH" : results.sldClassification] ?? ""}
                    </p>
                  </div>

                  <div className="space-y-4">
                    {/* FIB-4 */}
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">FIB-4 Score</p>
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-bold" data-testid="text-fib4-score">
                          {results.fib4Score != null ? results.fib4Score.toFixed(2) : results.isPediatric ? "—" : "N/A"}
                        </span>
                        <Badge variant="outline" className={`text-xs uppercase ${fib4RiskStyle}`}>
                          {results.fib4Risk} risk
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {results.isPediatric
                          ? "FIB-4 not validated in patients aged <18."
                          : "Formula: (Age × AST) / (Platelets × √ALT). Cutoff <1.3 low (age >65: <2.0), >2.67 high."}
                      </p>
                    </div>

                    {/* FAST Score */}
                    {results.fastScore != null && (
                      <div>
                        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">FAST Score</p>
                        <div className="flex items-baseline gap-2">
                          <span className="text-xl font-bold">{results.fastScore.toFixed(3)}</span>
                          <Badge
                            variant="outline"
                            className={`text-xs ${
                              results.fastScore >= 0.67
                                ? "bg-red-100 text-red-800 border-red-200"
                                : results.fastScore <= 0.35
                                ? "bg-emerald-100 text-emerald-800 border-emerald-200"
                                : "bg-amber-100 text-amber-800 border-amber-200"
                            }`}
                          >
                            {results.fastScore >= 0.67 ? "At-risk MASH" : results.fastScore <= 0.35 ? "MASH excluded" : "Indeterminate"}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          Newsome 2020 — requires FibroScan + AST + ALT. Rule-out ≤0.35, rule-in ≥0.67.
                        </p>
                      </div>
                    )}

                    {/* Maddrey's DF */}
                    {results.maddreysDF != null && (
                      <div className={results.maddreysDF >= 32 ? "p-3 bg-red-50 border border-red-200 rounded-md" : ""}>
                        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Maddrey's Discriminant Function</p>
                        <div className="flex items-baseline gap-2">
                          <span className={`text-xl font-bold ${results.maddreysDF >= 32 ? "text-red-700" : ""}`}>
                            {results.maddreysDF.toFixed(1)}
                          </span>
                          {results.maddreysDF >= 32 && (
                            <Badge className="bg-red-100 text-red-800 border-red-200 text-xs">
                              ≥32 — Severe (prednisolone)
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {results.maddreysDF >= 32
                            ? "Severe alcoholic hepatitis: prednisolone 40 mg/day × 28 days indicated (assess Lille score at day 7)."
                            : "Conservative management — alcohol cessation, nutritional support."}
                        </p>
                      </div>
                    )}

                    {/* MELD Score */}
                    {results.meldScore != null && (
                      <div>
                        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">MELD Score</p>
                        <div className="flex items-baseline gap-2">
                          <span className="text-xl font-bold">{results.meldScore}</span>
                          <Badge
                            variant="outline"
                            className={`text-xs ${
                              results.meldScore >= 20
                                ? "bg-red-100 text-red-800 border-red-200"
                                : results.meldScore >= 12
                                ? "bg-amber-100 text-amber-800 border-amber-200"
                                : "bg-emerald-100 text-emerald-800 border-emerald-200"
                            }`}
                          >
                            {results.meldScore >= 20 ? "High priority" : results.meldScore >= 12 ? "Transplant referral" : "Monitor"}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {results.meldScore >= 20
                            ? "MELD ≥20: high-priority liver transplant listing indicated."
                            : results.meldScore >= 12
                            ? "MELD ≥12 + decompensation: refer to transplant centre."
                            : "MELD <12: reassess every 3-6 months."}
                        </p>
                      </div>
                    )}

                    {/* Elastography */}
                    {assessment.imagingResults.transientElastographyKpa != null && (
                      <div>
                        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Liver Stiffness (FibroScan)</p>
                        <div className="flex items-baseline gap-2">
                          <span className="text-xl font-bold">{assessment.imagingResults.transientElastographyKpa} kPa</span>
                          {elastoRiskStyle && results.elastographyRisk && (
                            <Badge variant="outline" className={`text-xs uppercase ${elastoRiskStyle}`}>
                              {results.elastographyRisk} risk
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          Cutoffs: &lt;8 kPa low, 8-12 indeterminate, &gt;12 high, &gt;20 cirrhosis likely.
                        </p>
                      </div>
                    )}

                    {/* Fibrosis stage */}
                    {results.fibrosisStage && (
                      <div>
                        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Histological Fibrosis Stage</p>
                        <span className="text-xl font-bold">{results.fibrosisStage}</span>
                        {results.hasSignificantFibrosis && (
                          <Badge className="ml-2 bg-amber-100 text-amber-800 text-xs">Significant (F≥2)</Badge>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Summary banner */}
                <div className={`rounded-md border px-4 py-3 text-sm ${urgencyStyle}`}>
                  <p className="font-medium">{treatmentPlan.summary}</p>
                </div>
              </CardContent>
            </Card>

            {/* ── TREATMENT PLAN HEADING ── */}
            <div className="flex items-center gap-3 pt-1">
              <h2 className="text-xl font-bold tracking-tight">Recommended Treatment Plan</h2>
              <Separator className="flex-1" />
            </div>
            <p className="text-sm text-muted-foreground -mt-3">
              Based on EASL-EASD-EASO Clinical Practice Guidelines on MASLD (2024).
            </p>

            {/* Lifestyle Modifications */}
            <Card>
              <CardHeader className="pb-3 border-b">
                <CardTitle className="text-base flex items-center gap-2">
                  <HeartPulse className="h-4 w-4 text-emerald-600" />
                  Lifestyle Modifications
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <ul className="space-y-3" data-testid="list-lifestyle">
                  {treatmentPlan.lifestyleRecommendations.map((rec, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5 shrink-0" />
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Pharmacological & Specific Cause Options */}
            <Card>
              <CardHeader className="pb-3 border-b">
                <CardTitle className="text-base flex items-center gap-2">
                  <FlaskConical className="h-4 w-4 text-blue-600" />
                  Pharmacological Options & Specific Cause Management
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                {treatmentPlan.pharmacologicalOptions.length > 0 ? (
                  <ul className="space-y-3" data-testid="list-pharmacological">
                    {treatmentPlan.pharmacologicalOptions.map((rec, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm">
                        <Dot className="h-5 w-5 text-blue-600 shrink-0 -ml-1" />
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-muted-foreground italic">
                    No specific pharmacological interventions recommended at this stage. Focus on lifestyle modification and monitoring.
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Monitoring & Comorbidity Management */}
            <Card>
              <CardHeader className="pb-3 border-b">
                <CardTitle className="text-base flex items-center gap-2">
                  <ClipboardList className="h-4 w-4 text-amber-600" />
                  Monitoring, Follow-up & Comorbidity Management
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4 space-y-3">
                <ul className="space-y-3" data-testid="list-monitoring">
                  {treatmentPlan.monitoringPlan.map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm">
                      <Dot className="h-5 w-5 text-amber-600 shrink-0 -ml-1" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>

                {treatmentPlan.specialistReferral && (
                  <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-md flex items-start gap-3">
                    <Stethoscope className="h-5 w-5 text-amber-700 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-amber-900">Specialist Referral Required</p>
                      <p className="text-sm text-amber-800 mt-0.5">{treatmentPlan.specialistReferral}</p>
                    </div>
                  </div>
                )}

                {treatmentPlan.bariatricSurgeryConsidered && (
                  <div className="mt-3 p-4 bg-blue-50 border border-blue-200 rounded-md flex items-start gap-3">
                    <Scissors className="h-5 w-5 text-blue-700 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-blue-900">Bariatric Surgery Candidate</p>
                      <p className="text-sm text-blue-800 mt-0.5">
                        Patient meets criteria for bariatric/metabolic surgery evaluation. Refer to a multidisciplinary bariatric team.
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* ── Right: Patient profile ── */}
          <div className="space-y-5">
            <Card>
              <CardHeader className="pb-3 border-b">
                <CardTitle className="text-sm flex items-center gap-2">
                  <UserRound className="h-4 w-4" />
                  Patient Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4 text-sm space-y-4">
                <div className="grid grid-cols-2 gap-y-2">
                  <span className="text-muted-foreground">Age</span>
                  <span className="font-medium text-right">{assessment.age} yrs</span>
                  <span className="text-muted-foreground">Sex</span>
                  <span className="font-medium text-right capitalize">{assessment.sex}</span>
                  {assessment.ethnicity && (
                    <>
                      <span className="text-muted-foreground">Ethnicity</span>
                      <span className="font-medium text-right">{ETHNICITY_LABELS[assessment.ethnicity] ?? assessment.ethnicity}</span>
                    </>
                  )}
                  <span className="text-muted-foreground">BMI</span>
                  <span className="font-medium text-right">{assessment.bmi} kg/m²</span>
                  {assessment.waistCircumferenceCm != null && (
                    <>
                      <span className="text-muted-foreground">Waist</span>
                      <span className="font-medium text-right">{assessment.waistCircumferenceCm} cm</span>
                    </>
                  )}
                  <span className="text-muted-foreground">Alcohol</span>
                  <span className="font-medium text-right">{assessment.alcoholGramsPerDay} g/day</span>
                  <span className="text-muted-foreground">Steatosis</span>
                  <span className="font-medium text-right">{assessment.hasHepaticSteatosis ? "Confirmed" : "Absent"}</span>
                  {assessment.imagingResults.steatosisGrade && (
                    <>
                      <span className="text-muted-foreground">Steatosis grade</span>
                      <span className="font-medium text-right">{assessment.imagingResults.steatosisGrade}</span>
                    </>
                  )}
                </div>

                <Separator />

                <div>
                  <p className="font-medium mb-2">Cardiometabolic Factors</p>
                  <div className="flex flex-wrap gap-1.5">
                    {assessment.cardiometabolicFactors.hasT2Diabetes && <Badge variant="secondary" className="text-xs">T2D</Badge>}
                    {assessment.cardiometabolicFactors.hasPrediabetes && <Badge variant="secondary" className="text-xs">Prediabetes</Badge>}
                    {assessment.cardiometabolicFactors.hasHypertension && <Badge variant="secondary" className="text-xs">Hypertension</Badge>}
                    {assessment.cardiometabolicFactors.hasDyslipidemia && <Badge variant="secondary" className="text-xs">Dyslipidaemia</Badge>}
                    {assessment.cardiometabolicFactors.hasObesity && <Badge variant="secondary" className="text-xs">Obesity</Badge>}
                    {assessment.cardiometabolicFactors.hasCardiovascularDisease && <Badge variant="secondary" className="text-xs">CVD</Badge>}
                    {Object.values(assessment.cardiometabolicFactors).every(v => !v) && (
                      <span className="text-xs text-muted-foreground italic">None identified</span>
                    )}
                  </div>
                </div>

                {activeSecondaryCauses.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <p className="font-medium mb-2 flex items-center gap-1.5">
                        <Microscope className="h-3.5 w-3.5 text-violet-600" />
                        Secondary Causes
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {activeSecondaryCauses.map(cause => (
                          <Badge key={cause} className="text-xs bg-violet-100 text-violet-800 border-violet-200">{cause}</Badge>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                <Separator />

                <div>
                  <p className="font-medium mb-2">Lab Values</p>
                  <div className="grid grid-cols-2 gap-y-1.5 text-xs">
                    <span className="text-muted-foreground">AST</span>
                    <span className="text-right">{assessment.labValues.ast} U/L</span>
                    <span className="text-muted-foreground">ALT</span>
                    <span className="text-right">{assessment.labValues.alt} U/L</span>
                    <span className="text-muted-foreground">Platelets</span>
                    <span className="text-right">{assessment.labValues.plateletCount} ×10⁹/L</span>
                    {assessment.labValues.ggt != null && (
                      <><span className="text-muted-foreground">GGT</span><span className="text-right">{assessment.labValues.ggt} U/L</span></>
                    )}
                    {assessment.labValues.alp != null && (
                      <><span className="text-muted-foreground">ALP</span><span className="text-right">{assessment.labValues.alp} U/L</span></>
                    )}
                    {assessment.labValues.bilirubin != null && (
                      <><span className="text-muted-foreground">Bilirubin</span><span className="text-right">{assessment.labValues.bilirubin} μmol/L</span></>
                    )}
                    {assessment.labValues.inr != null && (
                      <><span className="text-muted-foreground">INR</span><span className="text-right">{assessment.labValues.inr}</span></>
                    )}
                    {assessment.labValues.albumin != null && (
                      <><span className="text-muted-foreground">Albumin</span><span className="text-right">{assessment.labValues.albumin} g/L</span></>
                    )}
                    {assessment.labValues.creatinine != null && (
                      <><span className="text-muted-foreground">Creatinine</span><span className="text-right">{assessment.labValues.creatinine} μmol/L</span></>
                    )}
                    {assessment.labValues.ferritin != null && (
                      <><span className="text-muted-foreground">Ferritin</span><span className="text-right">{assessment.labValues.ferritin} μg/L</span></>
                    )}
                    {assessment.labValues.hba1c != null && (
                      <><span className="text-muted-foreground">HbA1c</span><span className="text-right">{assessment.labValues.hba1c}%</span></>
                    )}
                    {assessment.labValues.fastingGlucose != null && (
                      <><span className="text-muted-foreground">Fasting glucose</span><span className="text-right">{assessment.labValues.fastingGlucose} mmol/L</span></>
                    )}
                    {assessment.labValues.triglycerides != null && (
                      <><span className="text-muted-foreground">Triglycerides</span><span className="text-right">{assessment.labValues.triglycerides} mmol/L</span></>
                    )}
                    {assessment.labValues.hdlCholesterol != null && (
                      <><span className="text-muted-foreground">HDL</span><span className="text-right">{assessment.labValues.hdlCholesterol} mmol/L</span></>
                    )}
                  </div>
                </div>

                {(assessment.imagingResults.transientElastographyKpa != null || assessment.imagingResults.hasHistologyData) && (
                  <>
                    <Separator />
                    <div>
                      <p className="font-medium mb-2">Imaging & Histology</p>
                      <div className="grid grid-cols-2 gap-y-1.5 text-xs">
                        {assessment.imagingResults.transientElastographyKpa != null && (
                          <><span className="text-muted-foreground">FibroScan</span><span className="text-right">{assessment.imagingResults.transientElastographyKpa} kPa</span></>
                        )}
                        {assessment.imagingResults.hasHistologyData && (
                          <>
                            {assessment.imagingResults.histologyFibrosisStage != null && (
                              <><span className="text-muted-foreground">Fibrosis stage</span><span className="text-right">F{assessment.imagingResults.histologyFibrosisStage}</span></>
                            )}
                            <span className="text-muted-foreground">Ballooning</span>
                            <span className="text-right">{assessment.imagingResults.histologyBallooningPresent ? "Present" : "Absent"}</span>
                            <span className="text-muted-foreground">Lobular inflammation</span>
                            <span className="text-right">{assessment.imagingResults.histologyLobularInflammationPresent ? "Present" : "Absent"}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </>
                )}

                {/* Hepatotoxic drugs summary */}
                {(() => {
                  const meds = assessment.hepatotoxicMedications;
                  const drugList = [
                    meds.amiodarone && "Amiodarone",
                    meds.methotrexate && "Methotrexate",
                    meds.tamoxifen && "Tamoxifen",
                    meds.corticosteroids && "Corticosteroids",
                    meds.valproicAcid && "Valproic Acid",
                    meds.tetracyclines && "Tetracyclines",
                    meds.nucleosideAnalogues && "NRTIs",
                    meds.nifedipine && "Nifedipine",
                    meds.diltiazem && "Diltiazem",
                    meds.irinotecan && "Irinotecan",
                    meds.oxaliplatin && "Oxaliplatin",
                    meds.lAsparaginase && "L-Asparaginase",
                    meds.estrogenOcp && "Estrogens/OCP",
                    meds.perhexiline && "Perhexiline",
                    meds.otherHepatotoxicDrug,
                  ].filter(Boolean) as string[];

                  return drugList.length > 0 ? (
                    <>
                      <Separator />
                      <div>
                        <p className="font-medium mb-2 flex items-center gap-1.5">
                          <Pill className="h-3.5 w-3.5 text-amber-600" />
                          Hepatotoxic Drugs
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {drugList.map(drug => (
                            <Badge key={drug} className="text-xs bg-amber-100 text-amber-800 border-amber-200">{drug}</Badge>
                          ))}
                        </div>
                      </div>
                    </>
                  ) : null;
                })()}

                {assessment.notes && (
                  <>
                    <Separator />
                    <div>
                      <p className="font-medium mb-1">Clinical Notes</p>
                      <p className="text-xs text-muted-foreground italic">{assessment.notes}</p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
