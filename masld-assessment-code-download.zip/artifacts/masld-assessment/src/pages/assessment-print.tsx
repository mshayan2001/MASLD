import { useGetAssessment, getGetAssessmentQueryKey } from "@workspace/api-client-react";
import { useParams } from "wouter";
import { format } from "date-fns";

export default function AssessmentPrint() {
  const params = useParams();
  const id = params.id ? parseInt(params.id, 10) : 0;

  const { data: assessment, isLoading, error } = useGetAssessment(id, {
    query: { enabled: !!id, queryKey: getGetAssessmentQueryKey(id) },
  });

  if (isLoading) return <div className="p-8">Loading print view...</div>;
  if (error || !assessment) return <div className="p-8">Assessment not found.</div>;

  const { results } = assessment;
  const treatmentPlan = results.treatmentPlan;

  setTimeout(() => { window.print(); }, 500);

  return (
    <div className="p-8 max-w-4xl mx-auto bg-white text-black print:p-0">
      <div className="border-b-2 border-black pb-4 mb-6">
        <h1 className="text-2xl font-bold uppercase tracking-wider">MASLD Clinical Assessment Report</h1>
        <div className="flex justify-between mt-4">
          <div>
            <p><strong>Patient:</strong> {assessment.patientName}</p>
            <p><strong>Age/Sex:</strong> {assessment.age} / {assessment.sex}</p>
          </div>
          <div className="text-right">
            <p><strong>Date:</strong> {format(new Date(assessment.createdAt), "MMMM d, yyyy")}</p>
            <p><strong>Record ID:</strong> #{assessment.id}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-8 mb-8">
        <div>
          <h2 className="text-lg font-bold border-b border-gray-300 mb-2 pb-1">Diagnosis & Risk</h2>
          <div className="space-y-2 text-sm">
            <p><strong>Classification:</strong> {results.hasMASH ? "MASH" : results.sldClassification}</p>
            <p><strong>MASH Status:</strong> {results.hasMASH ? "Confirmed" : "Not confirmed"}</p>
            <p><strong>FIB-4 Score:</strong> {results.fib4Score != null ? results.fib4Score.toFixed(2) : "N/A"} ({results.fib4Risk} risk)</p>
            {results.elastographyRisk && (
              <p><strong>Elastography Risk:</strong> {results.elastographyRisk}</p>
            )}
            <p><strong>Urgency Level:</strong> <span className="uppercase font-semibold">{treatmentPlan.urgencyLevel}</span></p>
            <p className="mt-2 italic text-gray-700">{treatmentPlan.summary}</p>
          </div>
        </div>

        <div>
          <h2 className="text-lg font-bold border-b border-gray-300 mb-2 pb-1">Clinical Data</h2>
          <div className="space-y-2 text-sm">
            <p><strong>BMI:</strong> {assessment.bmi} kg/m²</p>
            {assessment.waistCircumferenceCm != null && (
              <p><strong>Waist:</strong> {assessment.waistCircumferenceCm} cm</p>
            )}
            <p><strong>Alcohol:</strong> {assessment.alcoholGramsPerDay} g/day</p>
            <p><strong>AST / ALT:</strong> {assessment.labValues.ast} / {assessment.labValues.alt} U/L</p>
            <p><strong>Platelets:</strong> {assessment.labValues.plateletCount} ×10⁹/L</p>
          </div>
        </div>
      </div>

      <div className="mb-8">
        <h2 className="text-lg font-bold border-b border-gray-300 mb-3 pb-1">Treatment Plan</h2>

        <div className="mb-5">
          <h3 className="font-semibold mb-2">Lifestyle Recommendations</h3>
          <ul className="list-disc pl-5 text-sm space-y-1">
            {treatmentPlan.lifestyleRecommendations.map((rec: string, i: number) => (
              <li key={i}>{rec}</li>
            ))}
          </ul>
        </div>

        <div className="mb-5">
          <h3 className="font-semibold mb-2">Pharmacological Options</h3>
          {treatmentPlan.pharmacologicalOptions.length > 0 ? (
            <ul className="list-disc pl-5 text-sm space-y-1">
              {treatmentPlan.pharmacologicalOptions.map((rec: string, i: number) => (
                <li key={i}>{rec}</li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-600 italic text-sm">No specific pharmacological interventions recommended at this stage.</p>
          )}
        </div>

        <div className="mb-5">
          <h3 className="font-semibold mb-2">Monitoring, Follow-up & Comorbidity Management</h3>
          <ul className="list-disc pl-5 text-sm space-y-1">
            {treatmentPlan.monitoringPlan.map((rec: string, i: number) => (
              <li key={i}>{rec}</li>
            ))}
          </ul>
        </div>

        {treatmentPlan.specialistReferral && (
          <div className="mt-4 p-3 border-2 border-black font-semibold text-sm">
            Specialist Referral Required: {treatmentPlan.specialistReferral}
          </div>
        )}

        {treatmentPlan.bariatricSurgeryConsidered && (
          <div className="mt-3 p-3 border border-gray-400 text-sm">
            Bariatric/metabolic surgery evaluation should be considered for this patient.
          </div>
        )}
      </div>

      {assessment.notes && (
        <div>
          <h2 className="text-lg font-bold border-b border-gray-300 mb-2 pb-1">Clinical Notes</h2>
          <p className="whitespace-pre-wrap text-sm">{assessment.notes}</p>
        </div>
      )}
    </div>
  );
}
