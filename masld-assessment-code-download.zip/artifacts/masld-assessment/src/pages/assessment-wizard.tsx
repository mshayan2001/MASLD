import { useState, useMemo } from "react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { calculateMasldResults } from "@/lib/masldAlgorithm";
import {
  useCreateAssessment,
  AssessmentInput,
  AssessmentInputSex,
  AssessmentInputEthnicity,
  HepatotoxicMedications,
  SecondaryCauses,
} from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { ChevronRight, ChevronLeft, Save, AlertCircle, Pill, Microscope } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const STEPS = [
  "Patient Info",
  "Hepatic Steatosis",
  "Cardiometabolic Risk",
  "Secondary Causes",
  "Alcohol Intake",
  "Laboratory Values",
  "Imaging & Histology",
  "Hepatotoxic Medications",
  "Review & Submit",
];

type WizardData = Omit<AssessmentInput, "results">;

const EMPTY_MEDS: HepatotoxicMedications = {
  amiodarone: false,
  methotrexate: false,
  tamoxifen: false,
  corticosteroids: false,
  valproicAcid: false,
  tetracyclines: false,
  nucleosideAnalogues: false,
  nifedipine: false,
  diltiazem: false,
  irinotecan: false,
  oxaliplatin: false,
  lAsparaginase: false,
  estrogenOcp: false,
  perhexiline: false,
  otherHepatotoxicDrug: null,
};

const EMPTY_SECONDARY_CAUSES: SecondaryCauses = {
  hasHypothyroidism: false,
  hasPcos: false,
  hasHypopituitarism: false,
  hasCushingsSyndrome: false,
  hasCoeliaceDisease: false,
  hasObstructiveSleepApnoea: false,
  hasLipodystrophy: false,
  hasWilsonsDisease: false,
  hasTotalParenteralNutrition: false,
  hasRapidWeightLoss: false,
};

const INITIAL_DATA: WizardData = {
  patientName: "",
  age: 0,
  sex: "male",
  ethnicity: null,
  bmi: 0,
  waistCircumferenceCm: null,
  hasHepaticSteatosis: false,
  alcoholGramsPerDay: 0,
  cardiometabolicFactors: {
    hasT2Diabetes: false,
    hasPrediabetes: false,
    hasHypertension: false,
    hasDyslipidemia: false,
    hasObesity: false,
    hasCardiovascularDisease: false,
  },
  labValues: {
    ast: 0,
    alt: 0,
    plateletCount: 0,
    ggt: null,
    alp: null,
    bilirubin: null,
    inr: null,
    albumin: null,
    creatinine: null,
    ferritin: null,
    fastingGlucose: null,
    hba1c: null,
    triglycerides: null,
    hdlCholesterol: null,
  },
  imagingResults: {
    steatosisOnImaging: null,
    steatosisGrade: null,
    transientElastographyKpa: null,
    hasHistologyData: false,
    histologyBallooningPresent: null,
    histologyLobularInflammationPresent: null,
    histologyFibrosisStage: null,
  },
  secondaryCauses: EMPTY_SECONDARY_CAUSES,
  hepatotoxicMedications: EMPTY_MEDS,
  notes: "",
};

const SECONDARY_CAUSE_GROUPS: {
  label: string;
  causes: { key: keyof SecondaryCauses; name: string; detail: string }[];
}[] = [
  {
    label: "Endocrine & Hormonal",
    causes: [
      { key: "hasHypothyroidism", name: "Hypothyroidism", detail: "Impairs mitochondrial FA oxidation → hepatic steatosis; responds to levothyroxine" },
      { key: "hasPcos", name: "Polycystic Ovary Syndrome (PCOS)", detail: "Insulin resistance drives MASLD in ~50% of PCOS women; treat with metformin / GLP-1 RA" },
      { key: "hasHypopituitarism", name: "Hypopituitarism", detail: "GH deficiency → visceral obesity + steatosis; GH replacement can reverse liver disease" },
      { key: "hasCushingsSyndrome", name: "Cushing's Syndrome", detail: "Glucocorticoid excess → central obesity, insulin resistance, steatosis" },
    ],
  },
  {
    label: "Gastrointestinal",
    causes: [
      { key: "hasCoeliaceDisease", name: "Coeliac Disease", detail: "Intestinal inflammation + malabsorption drive steatosis; gluten-free diet reverses liver disease" },
    ],
  },
  {
    label: "Respiratory / Sleep",
    causes: [
      { key: "hasObstructiveSleepApnoea", name: "Obstructive Sleep Apnoea (OSA)", detail: "Nocturnal hypoxia → hepatic inflammation and fibrosis; CPAP therapy reduces liver injury" },
    ],
  },
  {
    label: "Metabolic / Genetic",
    causes: [
      { key: "hasLipodystrophy", name: "Lipodystrophy", detail: "Severe insulin resistance + extreme hypertriglyceridaemia; metreleptin therapy (generalised form)" },
      { key: "hasWilsonsDisease", name: "Wilson's Disease", detail: "Copper accumulation → steatosis and hepatitis; copper chelation (D-penicillamine / trientine)" },
    ],
  },
  {
    label: "Nutritional",
    causes: [
      { key: "hasTotalParenteralNutrition", name: "Total Parenteral Nutrition (TPN)", detail: "IFALD — gut trophic factor deficiency + lipid toxicity; switch to enteral nutrition where possible" },
      { key: "hasRapidWeightLoss", name: "Rapid Weight Loss / Starvation", detail: "Peripheral fat mobilised into liver faster than it can be processed; avoid VLCD <800 kcal without supervision" },
    ],
  },
];

const DRUG_GROUPS: { label: string; drugs: { key: keyof HepatotoxicMedications; name: string; detail: string }[] }[] = [
  {
    label: "Steatosis & Steatohepatitis",
    drugs: [
      { key: "amiodarone", name: "Amiodarone", detail: "Anti-arrhythmic — phospholipidosis, steatohepatitis, cirrhosis" },
      { key: "methotrexate", name: "Methotrexate", detail: "DMARD / chemotherapy — steatosis, cumulative fibrosis" },
      { key: "tamoxifen", name: "Tamoxifen", detail: "SERM (breast cancer) — steatohepatitis, fibrosis" },
      { key: "corticosteroids", name: "Corticosteroids / Glucocorticoids", detail: "Anti-inflammatory — macrovesicular steatosis" },
      { key: "valproicAcid", name: "Valproic Acid", detail: "Anticonvulsant — mitochondrial toxicity, micro/macrovesicular steatosis" },
    ],
  },
  {
    label: "Antimicrobials & Antivirals",
    drugs: [
      { key: "tetracyclines", name: "Tetracyclines", detail: "Antibiotic — microvesicular steatosis (mitochondrial toxicity)" },
      { key: "nucleosideAnalogues", name: "Nucleoside Analogues / Antiretrovirals", detail: "e.g. stavudine, didanosine, zidovudine — mitochondrial toxicity, lactic acidosis" },
    ],
  },
  {
    label: "Cardiovascular Drugs",
    drugs: [
      { key: "nifedipine", name: "Nifedipine", detail: "Calcium channel blocker — hepatic steatosis" },
      { key: "diltiazem", name: "Diltiazem", detail: "Calcium channel blocker — hepatic steatosis" },
    ],
  },
  {
    label: "Chemotherapy Agents",
    drugs: [
      { key: "irinotecan", name: "Irinotecan", detail: "Topoisomerase inhibitor — CASH (chemotherapy-associated steatohepatitis)" },
      { key: "oxaliplatin", name: "Oxaliplatin", detail: "Platinum agent — CASH, sinusoidal obstruction syndrome" },
      { key: "lAsparaginase", name: "L-Asparaginase", detail: "Haematological malignancy — hypertriglyceridaemia, steatosis" },
    ],
  },
  {
    label: "Hormonal & Other",
    drugs: [
      { key: "estrogenOcp", name: "High-dose Estrogens / OCP", detail: "Hormonal therapy — hepatic lipid accumulation" },
      { key: "perhexiline", name: "Perhexiline Maleate", detail: "Anti-anginal — phospholipidosis, steatohepatitis" },
    ],
  },
];

export default function AssessmentWizard() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState<WizardData>(INITIAL_DATA);
  const [, setLocation] = useLocation();
  const createAssessment = useCreateAssessment();

  const handleNext = () => { if (step < STEPS.length - 1) setStep(s => s + 1); };
  const handleBack = () => { if (step > 0) setStep(s => s - 1); };

  const updateData = (fields: Partial<WizardData>) => setData(prev => ({ ...prev, ...fields }));

  const updateCMF = (field: keyof WizardData["cardiometabolicFactors"], value: boolean) =>
    setData(prev => ({ ...prev, cardiometabolicFactors: { ...prev.cardiometabolicFactors, [field]: value } }));

  const updateLab = (field: keyof WizardData["labValues"], value: number | null) =>
    setData(prev => ({ ...prev, labValues: { ...prev.labValues, [field]: value } }));

  const updateImg = (field: keyof WizardData["imagingResults"], value: boolean | number | string | null) =>
    setData(prev => ({ ...prev, imagingResults: { ...prev.imagingResults, [field]: value } }));

  const updateSC = (field: keyof SecondaryCauses, value: boolean) =>
    setData(prev => ({ ...prev, secondaryCauses: { ...prev.secondaryCauses, [field]: value } }));

  const updateMed = (field: keyof HepatotoxicMedications, value: boolean | string | null) =>
    setData(prev => ({ ...prev, hepatotoxicMedications: { ...prev.hepatotoxicMedications, [field]: value } }));

  const activeDrugCount =
    Object.entries(data.hepatotoxicMedications)
      .filter(([k, v]) => k !== "otherHepatotoxicDrug" && v === true).length +
    (data.hepatotoxicMedications.otherHepatotoxicDrug ? 1 : 0);

  const activeSecondaryCount = Object.values(data.secondaryCauses).filter(Boolean).length;

  // Compute results only on the final review step (step 8)
  const computedResults = useMemo(() => {
    if (step === 8) return calculateMasldResults(data as AssessmentInput);
    return null;
  }, [data, step]);

  const handleSubmit = async () => {
    if (!computedResults) return;
    createAssessment.mutate(
      { data: { ...data, results: computedResults } },
      { onSuccess: (result) => setLocation(`/assessment/${result.id}`) }
    );
  };

  const isStepValid = () => {
    if (step === 0) return data.patientName.trim().length > 0 && data.age > 0 && data.bmi > 0;
    if (step === 5) return data.labValues.ast > 0 && data.labValues.alt > 0 && data.labValues.plateletCount > 0;
    return true;
  };

  return (
    <Layout>
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight mb-2">Clinical Assessment Wizard</h1>
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
            Step {step + 1} of {STEPS.length}:&nbsp;
            <span className="font-semibold text-foreground">{STEPS[step]}</span>
          </div>
          <Progress value={((step + 1) / STEPS.length) * 100} className="h-2" />
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {step === 3 && <Microscope className="h-5 w-5 text-violet-600" />}
              {step === 7 && <Pill className="h-5 w-5 text-amber-600" />}
              {STEPS[step]}
            </CardTitle>
            <CardDescription>
              {step === 0 && "Basic patient demographics, anthropometrics, and ethnicity for BMI cutoff adjustment."}
              {step === 1 && "Presence of hepatic steatosis is a prerequisite for all SLD diagnoses."}
              {step === 2 && "Identify the five cardiometabolic risk factors used to define MASLD."}
              {step === 3 && "Screen for specific causes of SLD (SC-SLD) per EASL 2024 — endocrine, metabolic, genetic, or nutritional conditions that independently cause steatosis."}
              {step === 4 && "Average daily alcohol intake is used to differentiate MASLD, MetALD, and ALD."}
              {step === 5 && "AST, ALT, and Platelets are required for FIB-4. Additional labs enable Maddrey's DF, MELD score, and metabolic comorbidity identification."}
              {step === 6 && "Advanced diagnostics: FibroScan for fibrosis assessment, liver biopsy for MASH confirmation, and steatosis grading."}
              {step === 7 && "Identify hepatotoxic drugs per EASL 2024. Drug-Induced SLD (DI-SLD) is classified when steatosis is drug-related without metabolic or alcohol causes."}
              {step === 8 && "Review computed clinical findings before saving this patient record."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            {/* ── STEP 0: Patient Info ── */}
            {step === 0 && (
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="patientName">Patient Name</Label>
                  <Input
                    id="patientName"
                    value={data.patientName}
                    onChange={e => updateData({ patientName: e.target.value })}
                    placeholder="John Doe"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="age">Age (years)</Label>
                  <Input
                    id="age"
                    type="number"
                    min="0"
                    value={data.age || ""}
                    onChange={e => updateData({ age: Number(e.target.value) })}
                  />
                  {data.age > 0 && data.age < 18 && (
                    <p className="text-xs text-violet-600 font-medium">Paediatric patient — age-specific guidelines will apply</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label>Biological Sex</Label>
                  <RadioGroup
                    value={data.sex}
                    onValueChange={(v: AssessmentInputSex) => updateData({ sex: v })}
                    className="flex gap-4 pt-1"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="male" id="sex-male" />
                      <Label htmlFor="sex-male">Male</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="female" id="sex-female" />
                      <Label htmlFor="sex-female">Female</Label>
                    </div>
                  </RadioGroup>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bmi">BMI (kg/m²)</Label>
                  <Input
                    id="bmi"
                    type="number"
                    min="0"
                    step="0.1"
                    value={data.bmi || ""}
                    onChange={e => updateData({ bmi: Number(e.target.value) })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="waist">Waist Circumference (cm) — Optional</Label>
                  <Input
                    id="waist"
                    type="number"
                    min="0"
                    value={data.waistCircumferenceCm || ""}
                    onChange={e => updateData({ waistCircumferenceCm: e.target.value ? Number(e.target.value) : null })}
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="ethnicity">Ethnicity — Optional</Label>
                  <Select
                    value={data.ethnicity ?? "none"}
                    onValueChange={(v) =>
                      updateData({ ethnicity: v === "none" ? null : (v as AssessmentInputEthnicity) })
                    }
                  >
                    <SelectTrigger id="ethnicity">
                      <SelectValue placeholder="Select ethnicity..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Not specified</SelectItem>
                      <SelectItem value="caucasian">Caucasian / European</SelectItem>
                      <SelectItem value="asian">Asian (South / East / Southeast Asian)</SelectItem>
                      <SelectItem value="african">African / Afro-Caribbean</SelectItem>
                      <SelectItem value="hispanic">Hispanic / Latin American</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  {data.ethnicity === "asian" && (
                    <p className="text-xs text-blue-700 font-medium">
                      Asian BMI cutoffs applied — overweight ≥23 kg/m², obesity ≥27.5 kg/m²; waist ≥90 cm (men), ≥80 cm (women)
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* ── STEP 1: Hepatic Steatosis ── */}
            {step === 1 && (
              <div className="space-y-6">
                <div className="p-4 border rounded-md bg-muted/20">
                  <div className="flex items-start space-x-3">
                    <Checkbox
                      id="steatosis"
                      checked={data.hasHepaticSteatosis}
                      onCheckedChange={(c) => updateData({ hasHepaticSteatosis: !!c })}
                      className="mt-1"
                    />
                    <div className="space-y-1 leading-none">
                      <Label htmlFor="steatosis" className="text-base font-semibold">Evidence of Hepatic Steatosis</Label>
                      <p className="text-sm text-muted-foreground">
                        Steatosis confirmed via imaging (ultrasound, MRI proton density fat fraction, CT), validated biomarkers (FibroScan CAP ≥288 dB/m), or liver biopsy (≥5% steatosis on histology).
                      </p>
                    </div>
                  </div>
                </div>
                {!data.hasHepaticSteatosis && (
                  <Alert variant="default" className="bg-blue-50 text-blue-900 border-blue-200">
                    <AlertCircle className="h-4 w-4 text-blue-600" />
                    <AlertTitle>Note</AlertTitle>
                    <AlertDescription>
                      Without confirmed hepatic steatosis, the patient will be classified as "No SLD" regardless of other findings.
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            )}

            {/* ── STEP 2: Cardiometabolic Risk ── */}
            {step === 2 && (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  MASLD requires ≥1 of the five cardiometabolic risk factors below. Tick all that apply.
                </p>
                <div className="grid gap-3 sm:grid-cols-2">
                  {[
                    { id: "t2d",   field: "hasT2Diabetes"         as const, label: "Type 2 Diabetes", hint: "Fasting glucose ≥7 mmol/L or HbA1c ≥6.5% or on treatment" },
                    { id: "pred",  field: "hasPrediabetes"         as const, label: "Prediabetes / IFG", hint: "Fasting glucose 5.6-6.9 mmol/L or HbA1c 5.7-6.4%" },
                    { id: "htn",   field: "hasHypertension"        as const, label: "Hypertension", hint: "BP ≥130/85 mmHg or on antihypertensive treatment" },
                    { id: "lip",   field: "hasDyslipidemia"        as const, label: "Dyslipidaemia", hint: "TG ≥1.7 mmol/L or HDL <1.0 men / <1.3 women mmol/L or on lipid-lowering therapy" },
                    { id: "obs",   field: "hasObesity"             as const, label: "Obesity / Overweight", hint: "BMI ≥25 kg/m² (≥23 Asian) or waist >94 cm men / >80 cm women" },
                    { id: "cvd",   field: "hasCardiovascularDisease" as const, label: "Established CVD", hint: "Coronary artery disease, stroke, peripheral artery disease" },
                  ].map(({ id, field, label, hint }) => (
                    <div
                      key={id}
                      className={`flex items-start space-x-3 p-3 border rounded-md transition-colors cursor-pointer ${
                        data.cardiometabolicFactors[field] ? "border-primary bg-primary/5" : "hover:border-muted-foreground/30"
                      }`}
                      onClick={() => updateCMF(field, !data.cardiometabolicFactors[field])}
                    >
                      <Checkbox
                        id={id}
                        checked={data.cardiometabolicFactors[field]}
                        onCheckedChange={(c) => updateCMF(field, !!c)}
                        className="mt-0.5"
                      />
                      <div onClick={e => e.stopPropagation()}>
                        <Label htmlFor={id} className="font-medium cursor-pointer">{label}</Label>
                        <p className="text-xs text-muted-foreground mt-0.5">{hint}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ── STEP 3: Secondary Causes ── */}
            {step === 3 && (
              <div className="space-y-6">
                <Alert className="bg-violet-50 border-violet-200 text-violet-900">
                  <Microscope className="h-4 w-4 text-violet-600" />
                  <AlertTitle>Specific Cause SLD (SC-SLD)</AlertTitle>
                  <AlertDescription>
                    Per EASL 2024: these conditions independently cause hepatic steatosis. If present <strong>without</strong> metabolic
                    risk factors or excess alcohol, the patient is classified as <strong>SC-SLD (OtherSLD)</strong>. If metabolic
                    factors are also present (MASLD), treatment of the underlying cause is still a priority.
                  </AlertDescription>
                </Alert>

                {activeSecondaryCount > 0 && (
                  <div className="flex items-center gap-2">
                    <Badge className="bg-violet-100 text-violet-800 border-violet-300">
                      {activeSecondaryCount} condition{activeSecondaryCount > 1 ? "s" : ""} selected
                    </Badge>
                    <span className="text-sm text-muted-foreground">— specific management included in treatment plan</span>
                  </div>
                )}

                {SECONDARY_CAUSE_GROUPS.map(group => (
                  <div key={group.label}>
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">{group.label}</h3>
                    <div className="grid gap-2 sm:grid-cols-2">
                      {group.causes.map(({ key, name, detail }) => (
                        <div
                          key={key}
                          className={`flex items-start space-x-3 p-3 border rounded-md transition-colors cursor-pointer ${
                            data.secondaryCauses[key] === true
                              ? "border-violet-400 bg-violet-50"
                              : "hover:border-muted-foreground/30"
                          }`}
                          onClick={() => updateSC(key, !(data.secondaryCauses[key] === true))}
                        >
                          <Checkbox
                            id={key}
                            checked={data.secondaryCauses[key] === true}
                            onCheckedChange={(c) => updateSC(key, !!c)}
                            className="mt-0.5"
                          />
                          <div className="space-y-0.5 leading-none" onClick={e => e.stopPropagation()}>
                            <Label htmlFor={key} className="font-medium cursor-pointer">{name}</Label>
                            <p className="text-xs text-muted-foreground">{detail}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ── STEP 4: Alcohol Intake ── */}
            {step === 4 && (
              <div className="space-y-6">
                <div className="space-y-2 max-w-sm">
                  <Label htmlFor="alcohol">Average Daily Alcohol Intake (grams/day)</Label>
                  <Input
                    id="alcohol"
                    type="number"
                    min="0"
                    value={data.alcoholGramsPerDay || ""}
                    onChange={e => updateData({ alcoholGramsPerDay: Number(e.target.value) })}
                  />
                  <p className="text-xs text-muted-foreground">1 standard drink ≈ 10-14 g pure alcohol (varies by country)</p>
                </div>
                <div className="bg-muted p-4 rounded-md text-sm space-y-2">
                  <p className="font-semibold">SLD Classification Thresholds (EASL 2024)</p>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-muted-foreground mt-2">
                    <span className="font-medium text-foreground">MASLD</span>
                    <span>≤30 g/day (Men) · ≤20 g/day (Women)</span>
                    <span className="font-medium text-foreground">MetALD</span>
                    <span>31-60 g/day (Men) · 21-50 g/day (Women)</span>
                    <span className="font-medium text-foreground">ALD</span>
                    <span>&gt;60 g/day (Men) · &gt;50 g/day (Women)</span>
                  </div>
                </div>
              </div>
            )}

            {/* ── STEP 5: Laboratory Values ── */}
            {step === 5 && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-semibold mb-1">Required — FIB-4 Calculation</h3>
                  <p className="text-xs text-muted-foreground mb-3">FIB-4 = (Age × AST) / (Platelets × √ALT). Not validated for age &lt;18.</p>
                  <div className="grid gap-4 sm:grid-cols-3">
                    <div className="space-y-2">
                      <Label htmlFor="ast">AST (U/L)</Label>
                      <Input id="ast" type="number" min="0" value={data.labValues.ast || ""} onChange={e => updateLab("ast", Number(e.target.value))} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="alt">ALT (U/L)</Label>
                      <Input id="alt" type="number" min="0" value={data.labValues.alt || ""} onChange={e => updateLab("alt", Number(e.target.value))} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="plt">Platelets (×10⁹/L)</Label>
                      <Input id="plt" type="number" min="0" value={data.labValues.plateletCount || ""} onChange={e => updateLab("plateletCount", Number(e.target.value))} />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h3 className="text-sm font-semibold mb-1">Liver Function & Severity</h3>
                  <p className="text-xs text-muted-foreground mb-3">Used for Maddrey's DF (ALD severity) and MELD score (transplant threshold).</p>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="alp">ALP — Alkaline Phosphatase (U/L)</Label>
                      <Input id="alp" type="number" min="0" value={data.labValues.alp ?? ""} onChange={e => updateLab("alp", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ggt">GGT (U/L)</Label>
                      <Input id="ggt" type="number" min="0" value={data.labValues.ggt ?? ""} onChange={e => updateLab("ggt", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bili">Total Bilirubin (μmol/L)</Label>
                      <Input id="bili" type="number" step="0.1" min="0" value={data.labValues.bilirubin ?? ""} onChange={e => updateLab("bilirubin", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="inr">INR</Label>
                      <Input id="inr" type="number" step="0.01" min="0" value={data.labValues.inr ?? ""} onChange={e => updateLab("inr", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="albumin">Albumin (g/L)</Label>
                      <Input id="albumin" type="number" step="0.1" min="0" value={data.labValues.albumin ?? ""} onChange={e => updateLab("albumin", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="creatinine">Creatinine (μmol/L)</Label>
                      <Input id="creatinine" type="number" min="0" value={data.labValues.creatinine ?? ""} onChange={e => updateLab("creatinine", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ferritin">Serum Ferritin (μg/L) — Optional</Label>
                      <Input id="ferritin" type="number" min="0" value={data.labValues.ferritin ?? ""} onChange={e => updateLab("ferritin", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h3 className="text-sm font-semibold mb-1">Metabolic Markers</h3>
                  <p className="text-xs text-muted-foreground mb-3">Used to identify cardiometabolic risk factors from lab results.</p>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="gluc">Fasting Glucose (mmol/L)</Label>
                      <Input id="gluc" type="number" step="0.1" min="0" value={data.labValues.fastingGlucose ?? ""} onChange={e => updateLab("fastingGlucose", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="hba1c">HbA1c (%)</Label>
                      <Input id="hba1c" type="number" step="0.1" min="0" value={data.labValues.hba1c ?? ""} onChange={e => updateLab("hba1c", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tg">Triglycerides (mmol/L)</Label>
                      <Input id="tg" type="number" step="0.1" min="0" value={data.labValues.triglycerides ?? ""} onChange={e => updateLab("triglycerides", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="hdl">HDL Cholesterol (mmol/L)</Label>
                      <Input id="hdl" type="number" step="0.1" min="0" value={data.labValues.hdlCholesterol ?? ""} onChange={e => updateLab("hdlCholesterol", e.target.value ? Number(e.target.value) : null)} />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ── STEP 6: Imaging & Histology ── */}
            {step === 6 && (
              <div className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="kpa">Liver Stiffness — FibroScan (kPa)</Label>
                    <Input
                      id="kpa"
                      type="number"
                      step="0.1"
                      min="0"
                      placeholder="Optional"
                      value={data.imagingResults.transientElastographyKpa ?? ""}
                      onChange={e => updateImg("transientElastographyKpa", e.target.value ? Number(e.target.value) : null)}
                    />
                    <p className="text-xs text-muted-foreground">Cutoffs: &lt;8 kPa low, 8-12 indeterminate, &gt;12 high, &gt;20 cirrhosis</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="steatosisGrade">Steatosis Grade (Imaging)</Label>
                    <Select
                      value={data.imagingResults.steatosisGrade ?? "none"}
                      onValueChange={(v) => updateImg("steatosisGrade", v === "none" ? null : v)}
                    >
                      <SelectTrigger id="steatosisGrade">
                        <SelectValue placeholder="Select grade..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Not graded / unknown</SelectItem>
                        <SelectItem value="S0">S0 — None (&lt;5%)</SelectItem>
                        <SelectItem value="S1">S1 — Mild (5-33%)</SelectItem>
                        <SelectItem value="S2">S2 — Moderate (34-66%)</SelectItem>
                        <SelectItem value="S3">S3 — Severe (&gt;66%)</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">From FibroScan CAP, ultrasound, or MRI-PDFF</p>
                  </div>
                </div>

                <div className="pt-4 border-t space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="hasHist"
                      checked={data.imagingResults.hasHistologyData}
                      onCheckedChange={(c) => updateImg("hasHistologyData", !!c)}
                    />
                    <Label htmlFor="hasHist" className="font-semibold">Liver Biopsy / Histology Data Available</Label>
                  </div>
                  {data.imagingResults.hasHistologyData && (
                    <div className="grid gap-4 sm:grid-cols-2 p-4 bg-muted/20 border rounded-md">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="balloon"
                          checked={data.imagingResults.histologyBallooningPresent || false}
                          onCheckedChange={(c) => updateImg("histologyBallooningPresent", !!c)}
                        />
                        <Label htmlFor="balloon">Hepatocyte Ballooning Present</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="inflam"
                          checked={data.imagingResults.histologyLobularInflammationPresent || false}
                          onCheckedChange={(c) => updateImg("histologyLobularInflammationPresent", !!c)}
                        />
                        <Label htmlFor="inflam">Lobular Inflammation Present</Label>
                      </div>
                      <div className="space-y-2 sm:col-span-2 mt-2">
                        <Label htmlFor="fibstage">Fibrosis Stage (0-4) — NASH-CRN / Ishak scale</Label>
                        <Input
                          id="fibstage"
                          type="number"
                          min="0"
                          max="4"
                          value={data.imagingResults.histologyFibrosisStage ?? ""}
                          onChange={e => updateImg("histologyFibrosisStage", e.target.value ? Number(e.target.value) : null)}
                          className="max-w-[150px]"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── STEP 7: Hepatotoxic Medications ── */}
            {step === 7 && (
              <div className="space-y-6">
                <Alert className="bg-amber-50 border-amber-200 text-amber-900">
                  <Pill className="h-4 w-4 text-amber-600" />
                  <AlertTitle>Drug-Induced SLD (DI-SLD)</AlertTitle>
                  <AlertDescription>
                    Per EASL-EASD-EASO 2024: DI-SLD is classified as OtherSLD when steatosis is
                    attributable to a hepatotoxic drug in the <strong>absence</strong> of metabolic risk
                    factors or excess alcohol. If metabolic factors are present, the drug worsens existing MASLD.
                  </AlertDescription>
                </Alert>

                {activeDrugCount > 0 && (
                  <div className="flex items-center gap-2">
                    <Badge variant="destructive">{activeDrugCount} drug{activeDrugCount > 1 ? "s" : ""} selected</Badge>
                    <span className="text-sm text-muted-foreground">— drug-specific management included in treatment plan</span>
                  </div>
                )}

                {DRUG_GROUPS.map(group => (
                  <div key={group.label}>
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">{group.label}</h3>
                    <div className="grid gap-2 sm:grid-cols-2">
                      {group.drugs.map(({ key, name, detail }) => (
                        <div
                          key={key}
                          className={`flex items-start space-x-3 p-3 border rounded-md transition-colors cursor-pointer ${
                            data.hepatotoxicMedications[key] === true
                              ? "border-amber-400 bg-amber-50"
                              : "hover:border-muted-foreground/30"
                          }`}
                          onClick={() => updateMed(key, !(data.hepatotoxicMedications[key] === true))}
                        >
                          <Checkbox
                            id={key}
                            checked={data.hepatotoxicMedications[key] === true}
                            onCheckedChange={(c) => updateMed(key, !!c)}
                            className="mt-0.5"
                          />
                          <div className="space-y-0.5 leading-none" onClick={e => e.stopPropagation()}>
                            <Label htmlFor={key} className="font-medium cursor-pointer">{name}</Label>
                            <p className="text-xs text-muted-foreground">{detail}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}

                <div className="pt-4 border-t space-y-2">
                  <Label htmlFor="otherDrug">Other Suspected Hepatotoxic Drug (Optional)</Label>
                  <Input
                    id="otherDrug"
                    placeholder="e.g. Amoxicillin-clavulanate, Fluconazole..."
                    value={data.hepatotoxicMedications.otherHepatotoxicDrug || ""}
                    onChange={e => updateMed("otherHepatotoxicDrug", e.target.value || null)}
                  />
                  <p className="text-xs text-muted-foreground">Free-text entry for drugs not listed above</p>
                </div>
              </div>
            )}

            {/* ── STEP 8: Review & Submit ── */}
            {step === 8 && computedResults && (
              <div className="space-y-6">
                <Alert className="bg-primary/10 border-primary/20">
                  <AlertCircle className="h-4 w-4 text-primary" />
                  <AlertTitle>Review Assessment</AlertTitle>
                  <AlertDescription>
                    Please review the computed clinical findings before saving this patient record.
                  </AlertDescription>
                </Alert>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-4 border rounded-md">
                    <p className="text-sm text-muted-foreground mb-1">SLD Classification</p>
                    <p className="text-lg font-bold">
                      {computedResults.hasMASH ? "MASH" : computedResults.sldClassification}
                    </p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {computedResults.isLeanMasld && (
                        <Badge variant="outline" className="text-xs bg-sky-50 text-sky-800 border-sky-300">Lean MASLD</Badge>
                      )}
                      {computedResults.isPediatric && (
                        <Badge variant="outline" className="text-xs bg-violet-50 text-violet-800 border-violet-300">Paediatric</Badge>
                      )}
                    </div>
                  </div>
                  <div className="p-4 border rounded-md">
                    <p className="text-sm text-muted-foreground mb-1">FIB-4 Score</p>
                    <p className="text-lg font-bold">{computedResults.fib4Score != null ? computedResults.fib4Score.toFixed(2) : "N/A"}</p>
                    <p className="text-sm capitalize font-medium">{computedResults.fib4Risk} risk</p>
                  </div>
                  {computedResults.fastScore != null && (
                    <div className="p-4 border rounded-md">
                      <p className="text-sm text-muted-foreground mb-1">FAST Score (at-risk MASH)</p>
                      <p className="text-lg font-bold">{computedResults.fastScore.toFixed(3)}</p>
                      <p className="text-xs text-muted-foreground">
                        {computedResults.fastScore >= 0.67 ? "≥0.67 — at-risk MASH likely" :
                         computedResults.fastScore <= 0.35 ? "≤0.35 — at-risk MASH excluded" :
                         "0.35-0.67 — indeterminate"}
                      </p>
                    </div>
                  )}
                  {computedResults.maddreysDF != null && (
                    <div className={`p-4 border rounded-md ${computedResults.maddreysDF >= 32 ? "border-red-300 bg-red-50" : ""}`}>
                      <p className="text-sm text-muted-foreground mb-1">Maddrey's Discriminant Function</p>
                      <p className="text-lg font-bold">{computedResults.maddreysDF.toFixed(1)}</p>
                      <p className={`text-xs font-medium ${computedResults.maddreysDF >= 32 ? "text-red-700" : "text-muted-foreground"}`}>
                        {computedResults.maddreysDF >= 32 ? "≥32 — Severe alcoholic hepatitis (prednisolone indication)" : "<32 — Conservative management"}
                      </p>
                    </div>
                  )}
                  {computedResults.meldScore != null && (
                    <div className="p-4 border rounded-md">
                      <p className="text-sm text-muted-foreground mb-1">MELD Score</p>
                      <p className="text-lg font-bold">{computedResults.meldScore}</p>
                      <p className="text-xs text-muted-foreground">
                        {computedResults.meldScore >= 20 ? "≥20 — High-priority transplant evaluation" :
                         computedResults.meldScore >= 12 ? "≥12 — Transplant referral indicated" :
                         "<12 — Monitor regularly"}
                      </p>
                    </div>
                  )}
                </div>

                {(activeSecondaryCount > 0 || activeDrugCount > 0) && (
                  <div className="space-y-2">
                    {activeSecondaryCount > 0 && (
                      <div className="p-4 border border-violet-300 rounded-md bg-violet-50">
                        <p className="text-sm font-semibold text-violet-800 mb-1 flex items-center gap-1">
                          <Microscope className="h-4 w-4" /> Secondary Causes Identified
                        </p>
                        <p className="text-sm text-violet-700">
                          {activeSecondaryCount} condition{activeSecondaryCount > 1 ? "s" : ""} recorded — specific management included in treatment plan.
                        </p>
                      </div>
                    )}
                    {activeDrugCount > 0 && (
                      <div className="p-4 border border-amber-300 rounded-md bg-amber-50">
                        <p className="text-sm font-semibold text-amber-800 mb-1 flex items-center gap-1">
                          <Pill className="h-4 w-4" /> Hepatotoxic Drugs Recorded
                        </p>
                        <p className="text-sm text-amber-700">
                          {activeDrugCount} drug{activeDrugCount > 1 ? "s" : ""} flagged — drug-specific management included in treatment plan.
                        </p>
                      </div>
                    )}
                  </div>
                )}

                <div className="space-y-2">
                  <Label>Clinical Notes (Optional)</Label>
                  <textarea
                    className="flex min-h-[80px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder="Add any additional clinical observations or context..."
                    value={data.notes || ""}
                    onChange={e => updateData({ notes: e.target.value })}
                  />
                </div>
              </div>
            )}

          </CardContent>
          <CardFooter className="flex justify-between border-t p-6 bg-muted/10">
            <Button variant="outline" onClick={handleBack} disabled={step === 0}>
              <ChevronLeft className="mr-2 h-4 w-4" /> Back
            </Button>
            {step < STEPS.length - 1 ? (
              <Button onClick={handleNext} disabled={!isStepValid()}>
                Next <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <Button onClick={handleSubmit} disabled={createAssessment.isPending}>
                {createAssessment.isPending ? "Saving..." : (
                  <><Save className="mr-2 h-4 w-4" /> Save Assessment</>
                )}
              </Button>
            )}
          </CardFooter>
        </Card>
      </div>
    </Layout>
  );
}
