import { FC, ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Stethoscope, FileText, Home as HomeIcon } from "lucide-react";

interface LayoutProps {
  children: ReactNode;
}

export const Layout: FC<LayoutProps> = ({ children }) => {
  const [location] = useLocation();

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col">
      <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6 py-4">
        <div className="flex items-center gap-2 font-semibold">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Stethoscope className="h-5 w-5" />
          </div>
          <span className="text-xl hidden sm:inline-block">MASLD Clinical Assessment</span>
        </div>
        <nav className="ml-auto flex items-center gap-4 sm:gap-6 text-sm font-medium">
          <Link
            href="/"
            className={`flex items-center gap-2 transition-colors hover:text-foreground ${location === "/" ? "text-foreground" : "text-muted-foreground"}`}
          >
            <HomeIcon className="h-4 w-4" />
            <span>Dashboard</span>
          </Link>
          <Link
            href="/assessment/new"
            className={`flex items-center gap-2 transition-colors hover:text-foreground ${location === "/assessment/new" ? "text-foreground" : "text-muted-foreground"}`}
          >
            <FileText className="h-4 w-4" />
            <span>New Assessment</span>
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-4 sm:px-6 sm:py-0 md:gap-8 max-w-6xl mx-auto w-full mb-10 mt-6">
        {children}
      </main>
    </div>
  );
};
