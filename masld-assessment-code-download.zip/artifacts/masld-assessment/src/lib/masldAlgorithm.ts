import {
  AssessmentInput,
  AssessmentResults,
  AssessmentResultsFib4Risk,
  AssessmentResultsSldClassification,
  TreatmentPlanUrgencyLevel,
  TreatmentPlan,
  AssessmentResultsElastographyRisk,
  HepatotoxicMedications,
  SecondaryCauses,
} from "@workspace/api-client-react";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getActiveDrugs(meds: HepatotoxicMedications): string[] {
  const drugMap: Record<keyof Omit<HepatotoxicMedications, "otherHepatotoxicDrug">, string> = {
    amiodarone: "Amiodarone",
    methotrexate: "Methotrexate",
    tamoxifen: "Tamoxifen",
    corticosteroids: "Corticosteroids/Glucocorticoids",
    valproicAcid: "Valproic Acid",
    tetracyclines: "Tetracyclines",
    nucleosideAnalogues: "Nucleoside Analogues / Antiretrovirals",
    nifedipine: "Nifedipine",
    diltiazem: "Diltiazem",
    irinotecan: "Irinotecan",
    oxaliplatin: "Oxaliplatin",
    lAsparaginase: "L-Asparaginase",
    estrogenOcp: "High-dose Estrogens / OCP",
    perhexiline: "Perhexiline Maleate",
  };
  const active: string[] = [];
  for (const [key, label] of Object.entries(drugMap) as [keyof typeof drugMap, string][]) {
    if (meds[key] === true) active.push(label);
  }
  if (meds.otherHepatotoxicDrug) active.push(meds.otherHepatotoxicDrug);
  return active;
}

function getActiveSecondaryCauses(sc: SecondaryCauses): string[] {
  const map: Record<keyof SecondaryCauses, string> = {
    hasHypothyroidism: "Hypothyroidism",
    hasPcos: "Polycystic Ovary Syndrome (PCOS)",
    hasHypopituitarism: "Hypopituitarism",
    hasCushingsSyndrome: "Cushing's Syndrome",
    hasCoeliaceDisease: "Coeliac Disease",
    hasObstructiveSleepApnoea: "Obstructive Sleep Apnoea (OSA)",
    hasLipodystrophy: "Lipodystrophy",
    hasWilsonsDisease: "Wilson's Disease",
    hasTotalParenteralNutrition: "Total Parenteral Nutrition (TPN)",
    hasRapidWeightLoss: "Rapid Weight Loss / Starvation",
  };
  return (Object.entries(map) as [keyof SecondaryCauses, string][])
    .filter(([key]) => sc[key] === true)
    .map(([, label]) => label);
}

// ─── Main function ─────────────────────────────────────────────────────────────

export function calculateMasldResults(input: AssessmentInput): AssessmentResults {
  const {
    age,
    sex,
    ethnicity,
    bmi,
    waistCircumferenceCm,
    hasHepaticSteatosis,
    alcoholGramsPerDay,
    cardiometabolicFactors: cmf,
    labValues,
    imagingResults,
    secondaryCauses: sc,
    hepatotoxicMedications: meds,
  } = input;

  const isMale = sex === "male";
  const isAsian = ethnicity === "asian";

  // Ethnicity-adjusted BMI and waist thresholds (EASL 2024 Table 1)
  const overweightBMI = isAsian ? 23 : 25;
  const obesityBMI    = isAsian ? 27.5 : 30;
  const waistMaleCutoff   = isAsian ? 90 : 94;  // cm
  const waistFemaleCutoff = 80; // same across all ethnic groups

  const activeDrugs = getActiveDrugs(meds);
  const hasHepatotoxicDrugs = activeDrugs.length > 0;
  const activeSecondaryCauses = getActiveSecondaryCauses(sc);
  const hasSecondaryCauses = activeSecondaryCauses.length > 0;

  const isPediatric = age < 18;

  // ─── 1. CARDIOMETABOLIC RISK FACTORS ─────────────────────────────────────────
  // Per EASL 2024: at least 1 of 5 criteria required for MASLD
  const cmFactors: boolean[] = [
    // 1. Overweight/obesity (ethnic-adjusted BMI or waist circumference)
    cmf.hasObesity ||
      bmi >= overweightBMI ||
      (waistCircumferenceCm != null && isMale  && waistCircumferenceCm > waistMaleCutoff) ||
      (waistCircumferenceCm != null && !isMale && waistCircumferenceCm > waistFemaleCutoff),

    // 2. Type 2 diabetes
    cmf.hasT2Diabetes,

    // 3. Prediabetes / impaired fasting glucose / impaired glucose tolerance
    cmf.hasPrediabetes ||
      (labValues.fastingGlucose != null && labValues.fastingGlucose >= 5.6) ||
      (labValues.hba1c != null && labValues.hba1c >= 5.7),

    // 4. Hypertension
    cmf.hasHypertension,

    // 5. Dyslipidaemia
    cmf.hasDyslipidemia ||
      (labValues.triglycerides != null && labValues.triglycerides >= 1.7) ||
      (labValues.hdlCholesterol != null &&  isMale && labValues.hdlCholesterol < 1.0) ||
      (labValues.hdlCholesterol != null && !isMale && labValues.hdlCholesterol < 1.3),
  ];
  const cmFactorCount = cmFactors.filter(Boolean).length;

  // ─── 2. SLD CLASSIFICATION ───────────────────────────────────────────────────
  // Hierarchy (EASL 2024 Figure 1):
  //   No steatosis → NoSLD
  //   Alcohol > ALD threshold → ALD
  //   ≥1 metabolic factor + alcohol ≤ MASLD threshold → MASLD
  //   ≥1 metabolic factor + alcohol in MetALD range → MetALD
  //   Specific secondary cause (no metabolic / alcohol) → OtherSLD (SC-SLD)
  //   Known hepatotoxic drug (no metabolic / alcohol) → OtherSLD (DI-SLD)
  //   None of the above → CryptogenicSLD
  let sldClassification: AssessmentResultsSldClassification = AssessmentResultsSldClassification.NoSLD;

  if (hasHepaticSteatosis) {
    const masldMaxAlcohol  = isMale ? 30 : 20;
    const metaldMaxAlcohol = isMale ? 60 : 50;

    if (alcoholGramsPerDay > metaldMaxAlcohol) {
      sldClassification = AssessmentResultsSldClassification.ALD;
    } else if (cmFactorCount >= 1) {
      sldClassification = alcoholGramsPerDay <= masldMaxAlcohol
        ? AssessmentResultsSldClassification.MASLD
        : AssessmentResultsSldClassification.MetALD;
    } else if (hasSecondaryCauses || hasHepatotoxicDrugs) {
      // Specific cause SLD — drug-induced or secondary condition
      sldClassification = AssessmentResultsSldClassification.OtherSLD;
    } else {
      sldClassification = AssessmentResultsSldClassification.CryptogenicSLD;
    }
  }

  // ─── 3. MASH DIAGNOSIS ───────────────────────────────────────────────────────
  // MASH = MASLD + histological ballooning + lobular inflammation (EASL 2024)
  let hasMASH = false;
  if (
    sldClassification === AssessmentResultsSldClassification.MASLD &&
    imagingResults.histologyBallooningPresent === true &&
    imagingResults.histologyLobularInflammationPresent === true
  ) {
    hasMASH = true;
    sldClassification = AssessmentResultsSldClassification.MASH;
  }

  // ─── 4. FIB-4 SCORE ──────────────────────────────────────────────────────────
  // Formula: (Age × AST) / (Platelets × √ALT)
  // Age-adjusted low cutoff: <1.3 (age ≤65) or <2.0 (age >65) — reduces false positives
  // High cutoff: >2.67 (all ages) — indicates high risk of advanced fibrosis
  // NOTE: FIB-4 is NOT validated in patients age <18
  let fib4Score: number | null = null;
  let fib4Risk: AssessmentResultsFib4Risk = AssessmentResultsFib4Risk.unavailable;

  const { ast, alt, plateletCount } = labValues;
  if (!isPediatric && age > 0 && ast > 0 && alt > 0 && plateletCount > 0) {
    fib4Score = Math.round(((age * ast) / (plateletCount * Math.sqrt(alt))) * 100) / 100;
    const lowCutoff = age > 65 ? 2.0 : 1.3;
    fib4Risk = fib4Score < lowCutoff
      ? AssessmentResultsFib4Risk.low
      : fib4Score <= 2.67
        ? AssessmentResultsFib4Risk.indeterminate
        : AssessmentResultsFib4Risk.high;
  }

  // ─── 5. FAST SCORE ────────────────────────────────────────────────────────────
  // Newsome et al., Lancet Gastroenterol Hepatol 2020
  // Identifies "at-risk MASH" (NAS ≥4 + ballooning ≥1 + fibrosis ≥2)
  // Requires: FibroScan (kPa), AST (U/L), ALT (U/L)
  // Formula: x = -1.65 + 1.07×ln(LSM) + 2.66×10⁻⁸×AST³ - 63.3×(ALT/AST)
  // FAST = eˣ / (1 + eˣ)   cutoffs: ≤0.35 rule out, ≥0.67 rule in
  const kpa = imagingResults.transientElastographyKpa;
  let fastScore: number | null = null;
  if (kpa != null && kpa > 0 && ast > 0 && alt > 0) {
    const x = -1.65 + 1.07 * Math.log(kpa) + 2.66e-8 * Math.pow(ast, 3) - 63.3 * (alt / ast);
    fastScore = Math.round((Math.exp(x) / (1 + Math.exp(x))) * 1000) / 1000;
  }

  // ─── 6. TRANSIENT ELASTOGRAPHY ───────────────────────────────────────────────
  // Baveno VII / EASL 2024 cutoffs for MASLD:
  //   <8 kPa  → low risk (F0-F1)
  //   8-12 kPa → indeterminate / grey zone
  //   >12 kPa  → high risk (F≥3)
  //   >20 kPa  → cirrhosis highly likely
  let elastographyRisk: AssessmentResultsElastographyRisk | null = null;
  if (kpa != null && kpa > 0) {
    elastographyRisk = kpa < 8
      ? AssessmentResultsElastographyRisk.low
      : kpa <= 12
        ? AssessmentResultsElastographyRisk.indeterminate
        : AssessmentResultsElastographyRisk.high;
  }

  // ─── 7. FIBROSIS STAGING ─────────────────────────────────────────────────────
  let fibrosisStage: string | null = null;
  let hasSignificantFibrosis = false; // F≥2
  let hasCirchosis = false;           // F4 or kPa >20

  if (imagingResults.histologyFibrosisStage != null) {
    fibrosisStage = `F${imagingResults.histologyFibrosisStage}`;
    if (imagingResults.histologyFibrosisStage >= 2) hasSignificantFibrosis = true;
    if (imagingResults.histologyFibrosisStage >= 4) hasCirchosis = true;
  } else {
    if (kpa != null && kpa > 20) hasCirchosis = true;
    if (elastographyRisk === AssessmentResultsElastographyRisk.high || fib4Risk === AssessmentResultsFib4Risk.high) {
      hasSignificantFibrosis = true;
    }
  }

  // ─── 8. MADDREY'S DISCRIMINANT FUNCTION (ALD) ────────────────────────────────
  // Used to assess severity of acute alcoholic hepatitis
  // DF = 4.6 × (PT prolongation in seconds) + serum bilirubin (mg/dL)
  // Using INR as proxy: PT prolongation ≈ (INR − 1) × 11 s (control PT ≈11 s)
  // DF ≥ 32 → severe alcoholic hepatitis → prednisolone 40 mg/day × 4 weeks
  let maddreysDF: number | null = null;
  const isAldSpectrum = sldClassification === AssessmentResultsSldClassification.ALD ||
                         sldClassification === AssessmentResultsSldClassification.MetALD;
  if (isAldSpectrum && labValues.inr != null && labValues.bilirubin != null) {
    const bilirubinMgDl = labValues.bilirubin / 17.1;
    maddreysDF = Math.round((4.6 * (labValues.inr - 1) * 11 + bilirubinMgDl) * 10) / 10;
  }

  // ─── 9. MELD SCORE ───────────────────────────────────────────────────────────
  // Used for transplant listing and prognosis in advanced liver disease
  // MELD = 3.78×ln(bilirubin mg/dL) + 11.2×ln(INR) + 9.57×ln(creatinine mg/dL) + 6.43
  // Values are clamped to ≥1; creatinine capped at 4.0 mg/dL
  let meldScore: number | null = null;
  if (labValues.bilirubin != null && labValues.inr != null && labValues.creatinine != null) {
    const bili   = Math.max(1, labValues.bilirubin / 17.1);
    const cr     = Math.max(1, Math.min(4, labValues.creatinine / 88.4));
    const inrVal = Math.max(1, labValues.inr);
    meldScore = Math.max(6, Math.round(3.78 * Math.log(bili) + 11.2 * Math.log(inrVal) + 9.57 * Math.log(cr) + 6.43));
  }

  // ─── 10. LEAN MASLD FLAG ─────────────────────────────────────────────────────
  // Lean MASLD: MASLD/MASH in a patient with BMI below the overweight threshold
  // Higher risk of advanced fibrosis; different weight-loss targets apply
  const isLeanMasld = (
    sldClassification === AssessmentResultsSldClassification.MASLD ||
    sldClassification === AssessmentResultsSldClassification.MASH
  ) && bmi < overweightBMI;

  // ─── 11. URGENCY LEVEL ───────────────────────────────────────────────────────
  let urgencyLevel: TreatmentPlanUrgencyLevel = TreatmentPlanUrgencyLevel.routine;

  if (
    hasCirchosis ||
    fib4Risk === AssessmentResultsFib4Risk.high ||
    (imagingResults.histologyFibrosisStage != null && imagingResults.histologyFibrosisStage >= 3) ||
    (maddreysDF != null && maddreysDF >= 32) ||
    (meldScore != null && meldScore >= 15)
  ) {
    urgencyLevel = TreatmentPlanUrgencyLevel.urgent;
  } else if (
    fib4Risk === AssessmentResultsFib4Risk.indeterminate ||
    hasMASH ||
    elastographyRisk === AssessmentResultsElastographyRisk.indeterminate ||
    (fastScore != null && fastScore >= 0.35) ||
    (hasHepatotoxicDrugs && sldClassification === AssessmentResultsSldClassification.OtherSLD) ||
    (hasSecondaryCauses && sldClassification === AssessmentResultsSldClassification.OtherSLD) ||
    sldClassification === AssessmentResultsSldClassification.ALD
  ) {
    urgencyLevel = TreatmentPlanUrgencyLevel.moderate;
  }

  // ─── 12. TREATMENT PLAN ──────────────────────────────────────────────────────

  // ── 12a. LIFESTYLE RECOMMENDATIONS ───────────────────────────────────────────
  const lifestyleRecommendations: string[] = [];

  if (isPediatric) {
    lifestyleRecommendations.push(
      "Paediatric MASLD — lifestyle is the cornerstone: structured family-based dietary modification and at least 60 min/day of moderate-to-vigorous physical activity. Target 5-10% BMI reduction. No pharmacotherapy is currently approved for children; GLP-1 RAs have emerging adolescent data."
    );
  } else if (isLeanMasld) {
    lifestyleRecommendations.push(
      "Lean MASLD: BMI is within the normal range but MASLD criteria are met. Even modest weight gain worsens disease; weight stabilisation and prevention of further gain are the primary goal. Target ≥5% weight reduction if feasible; this confers meaningful metabolic benefit."
    );
  } else if (bmi >= obesityBMI || cmf.hasObesity) {
    lifestyleRecommendations.push(
      "Weight loss ≥10% of body weight: achieves MASH resolution and fibrosis regression in most patients. ≥7% weight loss reduces steatohepatitis activity; ≥5% reduces hepatic steatosis. Target a caloric deficit of 500-1000 kcal/day."
    );
  } else if (bmi >= overweightBMI) {
    lifestyleRecommendations.push(
      "Modest weight loss (≥5-7% body weight) reduces hepatic steatosis and improves metabolic markers. Even 3-5% weight loss reduces liver fat content. Target a caloric deficit of 500 kcal/day."
    );
  }

  if (!isPediatric) {
    lifestyleRecommendations.push(
      "Mediterranean diet: high in vegetables, legumes, whole grains, oily fish, olive oil, and nuts; low in red and processed meat, refined carbohydrates, and sugar-sweetened beverages. The PREDIMED trial and multiple cohort studies confirm hepatic and cardiovascular benefit."
    );
    lifestyleRecommendations.push(
      "Avoid fructose and ultra-processed foods: high-fructose corn syrup and sugar-sweetened beverages directly drive hepatic de novo lipogenesis and MASLD progression. Read food labels; fructose is hidden in sauces, juices, and low-fat products."
    );
    lifestyleRecommendations.push(
      "Physical exercise: ≥150-300 min/week of moderate-intensity aerobic activity (e.g. brisk walking, cycling, swimming) PLUS resistance training 2-3×/week. Exercise reduces hepatic steatosis by 20-30% independently of weight loss."
    );
    lifestyleRecommendations.push(
      "Coffee consumption: 2-3 cups/day of filtered or espresso coffee (not energy drinks) is associated with reduced MASLD severity, slower fibrosis progression, and lower HCC risk. Mechanism includes anti-inflammatory polyphenols (chlorogenic acids) and caffeine."
    );
  }

  // Alcohol cessation / reduction
  if (hasCirchosis || hasSignificantFibrosis) {
    lifestyleRecommendations.push(
      "Complete and permanent alcohol abstinence is mandatory. Any alcohol in advanced fibrosis or cirrhosis accelerates decompensation, increases HCC risk, and reduces transplant eligibility."
    );
  } else if (sldClassification === AssessmentResultsSldClassification.ALD) {
    lifestyleRecommendations.push(
      "Alcohol cessation is the single most effective treatment for ALD. Brief interventions, motivational interviewing, and specialist alcohol services should be offered. Managed withdrawal with benzodiazepines (or chlormethiazole) if dependent. Nutritional support is critical: 35-40 kcal/kg/day, ≥1.2 g protein/kg/day."
    );
  } else if (sldClassification === AssessmentResultsSldClassification.MetALD) {
    lifestyleRecommendations.push(
      "Alcohol intake must be reduced below MASLD thresholds (≤30 g/day men, ≤20 g/day women) and ideally ceased entirely. Reduction to safe limits can reclassify the patient as MASLD and substantially improve prognosis."
    );
  } else if (
    sldClassification === AssessmentResultsSldClassification.MASLD ||
    sldClassification === AssessmentResultsSldClassification.MASH
  ) {
    lifestyleRecommendations.push(
      "Alcohol avoidance is strongly recommended even within the 'safe' MASLD threshold. Recent data show even low intake doubles the risk of incident liver disease progression in MASLD."
    );
  }

  if (!isPediatric) {
    lifestyleRecommendations.push(
      "Smoking cessation: smoking is an independent risk factor for MASLD, liver fibrosis, and HCC. Cessation support (varenicline, bupropion, or NRT) should be offered at every visit."
    );
  }

  // ── 12b. SECONDARY CAUSE SLD MANAGEMENT ──────────────────────────────────────
  const secondaryCauseRecommendations: string[] = [];

  if (hasSecondaryCauses) {
    secondaryCauseRecommendations.push(
      `Specific cause SLD (SC-SLD) identified: ${activeSecondaryCauses.join(", ")}. Address the underlying condition — resolution of the aetiology is the primary treatment target and can lead to complete reversal of hepatic steatosis.`
    );

    if (sc.hasHypothyroidism) {
      secondaryCauseRecommendations.push(
        "Hypothyroidism: thyroid hormone deficiency impairs mitochondrial fatty acid oxidation and drives hepatic steatosis. Initiate/optimise levothyroxine to achieve a normal TSH (0.4-4.0 mU/L). MASLD may improve significantly with euthyroidism alone. Check TSH every 6-12 months."
      );
    }
    if (sc.hasPcos) {
      secondaryCauseRecommendations.push(
        "Polycystic Ovary Syndrome (PCOS): affects ~50% of MASLD cases in pre-menopausal women. Insulin sensitisation is the primary target: metformin 500-2000 mg/day (also reduces liver enzymes), myo-inositol supplementation (4 g/day), and GLP-1 receptor agonists (semaglutide/tirzepatide) are all beneficial. Oral contraceptives should use the lowest androgenic formulation."
      );
    }
    if (sc.hasHypopituitarism) {
      secondaryCauseRecommendations.push(
        "Hypopituitarism: growth hormone (GH) deficiency is the key driver of MASLD in hypopituitarism — GH is essential for hepatic fat mobilisation. GH replacement therapy significantly reduces hepatic steatosis and visceral fat. Replace all deficient hormones (cortisol, thyroid, gonadal) under endocrinology supervision."
      );
    }
    if (sc.hasCushingsSyndrome) {
      secondaryCauseRecommendations.push(
        "Cushing's Syndrome: chronic glucocorticoid excess causes visceral obesity, insulin resistance, and hepatic steatosis. Treat the underlying cause (transsphenoidal surgery for Cushing's disease, adrenalectomy for adrenal adenoma, or medical therapy with metyrapone/ketoconazole/osilodrostat). MASLD typically resolves after normalisation of cortisol."
      );
    }
    if (sc.hasCoeliaceDisease) {
      secondaryCauseRecommendations.push(
        "Coeliac Disease: intestinal inflammation, malabsorption, and systemic immune activation all contribute to hepatic steatosis. Strict gluten-free diet (GFD) is mandatory and usually leads to normalisation of liver enzymes and hepatic fat within 6-12 months. Ensure nutritional supplementation (iron, folate, calcium, vitamin D)."
      );
    }
    if (sc.hasObstructiveSleepApnoea) {
      secondaryCauseRecommendations.push(
        "Obstructive Sleep Apnoea (OSA): intermittent nocturnal hypoxia drives hepatic inflammation and fibrosis via oxidative stress and sympathetic nervous system activation. CPAP therapy: initiation of CPAP reduces ALT, hepatic steatosis grade, and lobular inflammation. Titrate to AHI <5 events/hour. Weight loss addresses both OSA and MASLD simultaneously."
      );
    }
    if (sc.hasLipodystrophy) {
      secondaryCauseRecommendations.push(
        "Lipodystrophy: severe insulin resistance and extreme hypertriglyceridaemia cause massive hepatic steatosis and risk of acute pancreatitis. Metreleptin (recombinant leptin; FDA-approved for generalised lipodystrophy) reduces hepatic steatosis dramatically in leptin-deficient patients. Severe hypertriglyceridaemia (>11 mmol/L) requires fibrates or omega-3 fatty acids, and plasmapheresis in acute crises. Refer to specialist lipid/metabolic centre."
      );
    }
    if (sc.hasWilsonsDisease) {
      secondaryCauseRecommendations.push(
        "Wilson's Disease: copper accumulation causes steatosis, steatohepatitis, and progressive liver disease. Copper chelation: D-penicillamine (1st line) or trientine (better tolerated) to achieve urinary copper >200 μg/day. Zinc acetate 50 mg TID blocks intestinal copper absorption and is used for maintenance. Strict low-copper diet. Monitor with 24 h urine copper, caeruloplasmin, and serum copper. Liver transplantation for acute liver failure or decompensated cirrhosis."
      );
    }
    if (sc.hasTotalParenteralNutrition) {
      secondaryCauseRecommendations.push(
        "Total Parenteral Nutrition (TPN): intestinal failure-associated liver disease (IFALD) is caused by gut-trophic factor deficiency, bile acid dysregulation, and direct lipid toxicity. Transition to enteral nutrition as soon as possible. If TPN is unavoidable: use fish oil-based lipid emulsions (SMOF lipid), reduce caloric overfeeding, cycle TPN over 10-12 hours/day, and add ursodeoxycholic acid (UDCA 10-15 mg/kg/day). Refer to intestinal failure centre."
      );
    }
    if (sc.hasRapidWeightLoss) {
      secondaryCauseRecommendations.push(
        "Rapid Weight Loss / Starvation: paradoxically worsens hepatic steatosis and can trigger steatohepatitis by mobilising peripheral fat into the liver faster than it can be metabolised (occurs with >1.6 kg/week weight loss). Avoid very-low-calorie diets (<800 kcal/day) without medical supervision. Post-bariatric surgery: if MASH worsens, assess nutritional status, protein intake, and consider dumping syndrome."
      );
    }
  }

  // ── 12c. DRUG-INDUCED SLD MANAGEMENT ─────────────────────────────────────────
  const diSldRecommendations: string[] = [];

  if (hasHepatotoxicDrugs) {
    diSldRecommendations.push(
      `Causality assessment (RUCAM criteria): assess the temporal relationship between ${activeDrugs.join(", ")} and onset of steatosis. A positive RUCAM score (≥6) indicates probable DILI. Withdraw or substitute the offending drug where clinically safe.`
    );
    if (meds.amiodarone) {
      diSldRecommendations.push(
        "Amiodarone: half-life 40-55 days; hepatotoxicity may persist for months after cessation. If it cannot be discontinued (life-threatening arrhythmia), minimise dose, monitor LFTs monthly, and consider FibroScan every 6-12 months. Switch to dronedarone after cardiology review if feasible."
      );
    }
    if (meds.methotrexate) {
      diSldRecommendations.push(
        "Methotrexate: cumulative fibrosis risk increases significantly above 1.5 g lifetime dose. Perform FibroScan or liver biopsy every 1.0-1.5 g cumulative. Mandatory folic acid 5 mg/week. Discontinue if histological F≥3. Switch to leflunomide or biologic DMARDs in rheumatology; switch to alternative for psoriasis."
      );
    }
    if (meds.tamoxifen) {
      diSldRecommendations.push(
        "Tamoxifen: hepatic steatosis and steatohepatitis in ~33% of users, more common in women with obesity. Aromatase inhibitors (anastrozole, letrozole) are an evidence-based alternative that does NOT cause hepatic steatosis — discuss switch with oncologist where hormonally appropriate."
      );
    }
    if (meds.corticosteroids) {
      diSldRecommendations.push(
        "Corticosteroids: use lowest effective dose for shortest duration. For unavoidable long-term therapy, monitor HbA1c, lipid profile, and LFTs quarterly. Consider steroid-sparing immunosuppressants (azathioprine, mycophenolate, biologics). Inhaled/topical steroids carry negligible hepatic risk."
      );
    }
    if (meds.valproicAcid) {
      diSldRecommendations.push(
        "Valproic Acid: monitor LFTs and ammonia every 3 months. Measure plasma carnitine — supplementation (L-carnitine 50-100 mg/kg/day) may protect against mitochondrial toxicity. Switch to levetiracetam, lamotrigine, or lacosamide under neurology guidance if hepatotoxicity is significant."
      );
    }
    if (meds.tetracyclines) {
      diSldRecommendations.push(
        "Tetracyclines: avoid IV formulations (higher hepatotoxic risk). Switch to doxycycline (lower risk), azithromycin, or a fluoroquinolone. Microvesicular steatosis typically reverses within 1-3 months of cessation."
      );
    }
    if (meds.nucleosideAnalogues) {
      diSldRecommendations.push(
        "Nucleoside Analogues / NRTIs (stavudine, didanosine, zidovudine): mitochondrial toxicity causes microvesicular steatosis and potentially fatal lactic acidosis. Switch to modern low-toxicity regimens (tenofovir alafenamide/emtricitabine or abacavir/lamivudine) under HIV specialist supervision. Measure lactate if symptomatic."
      );
    }
    if (meds.irinotecan || meds.oxaliplatin) {
      const chemo = [meds.irinotecan && "Irinotecan", meds.oxaliplatin && "Oxaliplatin"].filter(Boolean).join(" and ");
      diSldRecommendations.push(
        `${chemo} (CASH — Chemotherapy-Associated Steatohepatitis): assess liver remnant function before hepatic resection. Allow ≥4 weeks washout before liver surgery. Bevacizumab co-administration reduces irinotecan-associated CASH. Assess for sinusoidal obstruction syndrome (oxaliplatin) with MRI or liver biopsy.`
      );
    }
    if (meds.lAsparaginase) {
      diSldRecommendations.push(
        "L-Asparaginase: causes hypertriglyceridaemia (TG often >10 mmol/L) and hepatic steatosis. Monitor TG before each cycle; if >10 mmol/L consider dose delay and fibrates. Pegylated asparaginase (Oncaspar) has a better lipid safety profile. Lipaemic plasmapheresis if TG >20 mmol/L with pancreatitis risk."
      );
    }
    if (meds.nifedipine || meds.diltiazem) {
      const ccb = [meds.nifedipine && "Nifedipine", meds.diltiazem && "Diltiazem"].filter(Boolean).join(" and ");
      diSldRecommendations.push(
        `${ccb} (calcium channel blocker): switch to ACE inhibitor or ARB-based antihypertensive regimen — these agents have a potential anti-fibrotic hepatic benefit in MASLD and avoid the steatogenic effect of CCBs.`
      );
    }
    if (meds.estrogenOcp) {
      diSldRecommendations.push(
        "Estrogens / OCP: switch to the lowest-dose formulation or to progestogen-only or non-hormonal contraception. Post-menopausal HRT: transdermal estrogen has a much lower hepatic first-pass effect than oral formulations and is preferred in women with MASLD."
      );
    }
    if (meds.perhexiline) {
      diSldRecommendations.push(
        "Perhexiline: CYP2D6 poor metabolisers accumulate toxic levels — genotype testing before initiation is recommended. Therapeutic drug monitoring mandatory (target 0.15-0.6 mg/L). Discontinue immediately if hepatotoxicity confirmed. Steatohepatitis usually reverses within 3-6 months of cessation."
      );
    }
    if (sldClassification === AssessmentResultsSldClassification.OtherSLD) {
      diSldRecommendations.push(
        "DI-SLD monitoring after drug withdrawal: LFTs every 4-8 weeks. Expect normalisation within 3 months. If no improvement after 3 months, perform liver biopsy to exclude co-existing primary liver disease. FibroScan at baseline and 6 months post-cessation."
      );
    } else {
      diSldRecommendations.push(
        "Drug contribution to MASLD: the listed drug(s) likely worsen existing metabolic steatosis. Substitute where clinically safe; this may reduce the pharmacological treatment burden for MASLD."
      );
    }
  }

  // ── 12d. COMORBIDITY MANAGEMENT ──────────────────────────────────────────────
  const comorbidityManagement: string[] = [];

  if (cmf.hasT2Diabetes || cmf.hasPrediabetes) {
    comorbidityManagement.push(
      "Glycaemic optimisation: target HbA1c <7.0% (individualised). Prefer agents with proven hepatic and cardiovascular benefit: GLP-1 RAs (semaglutide, tirzepatide), SGLT2i (empagliflozin, dapagliflozin), or pioglitazone. Metformin is safe in MASLD but has no direct liver benefit. Avoid sulphonylureas and insulin as first choice (weight gain)."
    );
  }
  if (cmf.hasHypertension) {
    comorbidityManagement.push(
      "Hypertension: target BP <130/80 mmHg. ACE inhibitors (ramipril, enalapril) or ARBs (losartan, irbesartan) are first-line in MASLD — they reduce hepatic stellate cell activation and may slow fibrosis. Avoid beta-blockers in non-cirrhotic MASLD (worsen insulin resistance) unless cardiac indication. In cirrhosis, non-selective beta-blockers (propranolol, carvedilol) reduce portal hypertension."
    );
  }
  if (cmf.hasDyslipidemia) {
    comorbidityManagement.push(
      "Dyslipidaemia: statins (atorvastatin 10-40 mg, rosuvastatin 5-20 mg) are safe in MASLD including compensated cirrhosis and should NOT be withheld due to elevated liver enzymes — transaminase elevation in MASLD is disease-related, not statin-induced. Add ezetimibe 10 mg if LDL ≥1.4 mmol/L persists. Omega-3 fatty acids 2-4 g/day for isolated hypertriglyceridaemia."
    );
  }
  if (cmf.hasCardiovascularDisease) {
    comorbidityManagement.push(
      "Cardiovascular disease: MASLD is an independent cardiovascular risk factor equivalent to T2DM. Ensure dual antiplatelet therapy (if recent ACS), statin therapy to LDL <1.4 mmol/L (<1.0 mmol/L if very high CV risk), ACE/ARB for blood pressure, and low-dose aspirin for secondary prevention. Calculate SCORE2/SCORE2-OP annually and refer to cardiologist if ≥10% 10-year CV risk."
    );
  }

  // ── 12e. PHARMACOLOGICAL OPTIONS ─────────────────────────────────────────────
  const pharmacologicalOptions: string[] = [];

  // ALD-specific pharmacotherapy (most urgent — comes first)
  if (isAldSpectrum) {
    pharmacologicalOptions.push(
      "Alcohol use disorder treatment: offer pharmacotherapy for alcohol dependence — naltrexone 50 mg/day (reduces craving; avoid in active liver injury), acamprosate 666 mg TID (promotes abstinence; renally cleared — safe in liver disease), or baclofen 5-20 mg TID (hepatically safe, evidence in cirrhosis). Disulfiram is CONTRAINDICATED in significant liver disease."
    );
  }
  if (maddreysDF != null && maddreysDF >= 32) {
    pharmacologicalOptions.push(
      `SEVERE ALCOHOLIC HEPATITIS (Maddrey's DF ${maddreysDF.toFixed(1)} ≥32): prednisolone 40 mg/day orally for 28 days (Lille model reassessment at day 7 — if Lille score >0.45, early non-response confirmed → stop prednisolone early). Exclude contraindications: active infection, GI bleeding, renal failure (creatinine >250 μmol/L), hepatorenal syndrome. If prednisolone contraindicated: pentoxifylline 400 mg TID × 28 days (weaker evidence; primarily reduces hepatorenal syndrome risk).`
    );
  }

  // GLP-1 receptor agonists
  if (cmf.hasT2Diabetes || cmf.hasObesity || bmi >= obesityBMI || sc.hasPcos) {
    pharmacologicalOptions.push(
      "GLP-1 receptor agonists — semaglutide (Wegovy 2.4 mg/week SC) or tirzepatide (Mounjaro/Zepbound, dual GLP-1/GIP): first-line pharmacological agents in MASLD with T2D or obesity. Semaglutide Phase 3 NASH trial: 59% MASH resolution vs 17% placebo. Tirzepatide SURMOUNT-NASH: 62.4% MASH resolution (10 mg) with fibrosis improvement. Both agents produce 12-22% weight loss and significantly improve all cardiometabolic parameters."
    );
  }

  // Pioglitazone
  if ((cmf.hasT2Diabetes || cmf.hasPrediabetes) && hasMASH) {
    pharmacologicalOptions.push(
      "Pioglitazone 30-45 mg/day: TZD recommended for T2D or prediabetes with biopsy-confirmed MASH (EASL 2024 recommendation). Improves steatohepatitis in 50-70% of patients; modest fibrosis reduction. Monitor for fluid retention (contraindicated in heart failure NYHA III-IV), weight gain (~3 kg), and fracture risk in women. Discontinue if no response at 6 months."
    );
  }

  // SGLT2 inhibitors
  if (cmf.hasT2Diabetes) {
    pharmacologicalOptions.push(
      "SGLT2 inhibitors — empagliflozin 10-25 mg/day or dapagliflozin 10 mg/day: recommended for T2D in MASLD, especially with established CVD, heart failure, or CKD. Reduce hepatic steatosis by 15-25%, improve liver enzymes, and provide robust cardiovascular and renal protection. Avoid in eGFR <30 mL/min/1.73m²."
    );
  }

  // Resmetirom
  if (hasMASH && hasSignificantFibrosis && !hasCirchosis) {
    pharmacologicalOptions.push(
      "Resmetirom (Rezdiffra) 80-100 mg/day — thyroid hormone receptor-β agonist: FDA-approved March 2024 for non-cirrhotic MASH with significant fibrosis (F≥2). MAESTRO-NASH Phase 3: 26% MASH resolution without fibrosis worsening (vs 10% placebo), 24% ≥1-stage fibrosis improvement (vs 14% placebo). Selectively activates hepatic THR-β, lowering LDL by 16-26%. Monitor thyroid function and potential CYP interactions. Not yet EMA-approved; check local formulary."
    );
  }

  // Vitamin E
  if (hasMASH && !cmf.hasT2Diabetes && !hasCirchosis && !isPediatric) {
    pharmacologicalOptions.push(
      "Vitamin E (α-tocopherol) 800 IU/day: may be considered in non-diabetic adults with biopsy-confirmed MASH without cirrhosis (EASL grade B recommendation). PIVENS trial: 43% MASH resolution vs 19% placebo. Improves steatohepatitis but NOT fibrosis. Avoid in patients with high cardiovascular risk or history of haemorrhagic stroke. Long-term safety data limited beyond 2 years."
    );
  }

  // Statins in MASLD (for dyslipidaemia — cardiovascular risk reduction)
  if (cmf.hasDyslipidemia && !hasCirchosis) {
    pharmacologicalOptions.push(
      "Statins (atorvastatin 10-40 mg, rosuvastatin 5-20 mg): do NOT withhold in MASLD or compensated cirrhosis. Transaminase elevation in MASLD is disease-related, not statin-induced — routine LFT monitoring is not required unless symptomatic. Statins may reduce HCC risk by 37% in MASLD patients."
    );
  }

  // Bariatric surgery
  const bariatricSurgeryConsidered =
    (bmi >= 35 || (bmi >= 30 && (cmf.hasT2Diabetes || cmf.hasHypertension || cmf.hasObesity))) &&
    (sldClassification === AssessmentResultsSldClassification.MASLD ||
      sldClassification === AssessmentResultsSldClassification.MASH ||
      sldClassification === AssessmentResultsSldClassification.MetALD);

  if (bariatricSurgeryConsidered) {
    pharmacologicalOptions.push(
      "Bariatric/metabolic surgery: consider when BMI ≥35 kg/m² (or ≥30 with major comorbidities: T2D, hypertension, severe OSA) and lifestyle+pharmacological interventions have not achieved adequate weight loss. Sleeve gastrectomy or Roux-en-Y gastric bypass achieves MASH resolution in 80-90% of patients and fibrosis regression in >40%. Multidisciplinary team evaluation required. Note: if pre-surgical liver biopsy shows F3-F4, bariatric risk is higher — discuss with hepatologist."
    );
  }

  if (hasCirchosis) {
    pharmacologicalOptions.push(
      "Cirrhosis pharmacotherapy: no MASH-targeted therapy is approved for the cirrhotic stage. Statins may continue in compensated cirrhosis (Child-Pugh A). Metformin: avoid in decompensated cirrhosis (lactic acidosis risk). GLP-1 RAs: limited safety data in Child-Pugh B/C — use with caution. All medications require dose review with hepatologist."
    );
  }

  // ── 12f. MONITORING PLAN ─────────────────────────────────────────────────────
  const monitoringPlan: string[] = [];

  if (hasCirchosis) {
    monitoringPlan.push(
      "HCC surveillance: ultrasound ± AFP every 6 months. If ultrasound technically limited (BMI >35, steatosis), use contrast-enhanced CT or MRI liver. Consider AFP-L3 and DCP in high-risk patients."
    );
    monitoringPlan.push(
      "Portal hypertension (Baveno VII): EGD at diagnosis. If no varices at low-risk LSM (<20 kPa) + PLT (>150×10⁹/L): repeat EGD in 2-3 years. High-risk varices (large or red signs): carvedilol 6.25-12.5 mg/day or propranolol, or endoscopic band ligation."
    );
    monitoringPlan.push(
      "Liver transplantation: refer if Child-Pugh B/C or MELD ≥12 with decompensation (ascites, encephalopathy, variceal haemorrhage, SBP, HRS). Pre-listing requirements: alcohol abstinence ≥3-6 months (ALD), bariatric programme evaluation (obese MASLD), cardiological clearance."
    );
    monitoringPlan.push(
      "Decompensation management: ascites (aldactone 100-400 mg + frusemide 40-160 mg, dietary sodium <88 mmol/day); spontaneous bacterial peritonitis (cefotaxime IV + albumin 1.5 g/kg); hepatic encephalopathy (lactulose, rifaximin 550 mg BID)."
    );
    monitoringPlan.push(
      "Nutritional assessment: screen for sarcopenia (hand-grip, DEXA, CT L3 muscle index). Target protein ≥1.2-1.5 g/kg/day, calories 35 kcal/kg/day, late-night snack with complex carbohydrates (40 g) to prevent overnight fasting catabolism."
    );
    if (meldScore != null) {
      monitoringPlan.push(
        `MELD score: ${meldScore}. ${meldScore >= 20 ? "High-priority transplant evaluation required urgently." : meldScore >= 12 ? "Transplant referral indicated." : "Monitor MELD every 3-6 months."}`
      );
    }
  } else if (urgencyLevel === TreatmentPlanUrgencyLevel.urgent) {
    monitoringPlan.push(
      "Urgent hepatology referral within 4-8 weeks: FIB-4 >2.67 or histological F3-F4 indicates advanced fibrosis requiring specialist assessment. Liver biopsy may be needed to guide resmetirom eligibility."
    );
    monitoringPlan.push("Repeat FIB-4 and elastography at 12 months after initiating treatment to document fibrosis regression.");
    if (maddreysDF != null && maddreysDF >= 32) {
      monitoringPlan.push(
        `Alcoholic hepatitis monitoring: Maddrey DF ${maddreysDF.toFixed(1)} — if starting prednisolone, reassess with Lille score at day 7. If Lille >0.45 → early non-response, stop prednisolone. Monitor INR, creatinine, bilirubin every 2-3 days during treatment. Hospital admission likely required.`
      );
    }
  } else if (urgencyLevel === TreatmentPlanUrgencyLevel.moderate) {
    if (fib4Risk === AssessmentResultsFib4Risk.indeterminate) {
      monitoringPlan.push(
        "Second-step fibrosis assessment: FibroScan (transient elastography) or other validated imaging (MRE, ARFI) within 3-6 months to resolve indeterminate FIB-4 result."
      );
    }
    if (fastScore != null) {
      monitoringPlan.push(
        `FAST score: ${fastScore.toFixed(3)}. ${
          fastScore >= 0.67
            ? "FAST ≥0.67 — at-risk MASH likely: refer for liver biopsy to confirm diagnosis and fibrosis stage."
            : fastScore >= 0.35
            ? "FAST 0.35-0.67 — indeterminate: correlate with FIB-4 and clinical findings. Consider elastography."
            : "FAST ≤0.35 — at-risk MASH unlikely: routine surveillance sufficient."
        }`
      );
    }
    if (hasMASH) {
      monitoringPlan.push(
        "MASH-specific follow-up: LFTs + FIB-4 every 6 months; elastography annually. Repeat liver biopsy if significant clinical change (weight gain >5%, worsening T2D, new hepatic decompensation)."
      );
    }
    monitoringPlan.push(
      "Lifestyle response: weight, metabolic markers, and adherence review every 3 months. If <5% weight loss after 6 months of intensive lifestyle intervention → escalate to pharmacotherapy (GLP-1 RA or bariatric surgery referral)."
    );
  } else {
    // Routine
    monitoringPlan.push(
      "FIB-4 reassessment every 1-2 years in primary care. Repeat annually if weight gain >5%, new T2D or metabolic risk factor, or ALT doubles from baseline."
    );
    monitoringPlan.push(
      "Annual metabolic review: BMI, waist circumference, blood pressure, HbA1c, fasting lipids. Reinforce lifestyle targets at every consultation."
    );
    if (isPediatric) {
      monitoringPlan.push(
        "Paediatric monitoring: FIB-4 is not validated under age 18 — use AST/ALT ratio and ultrasound for fibrosis surveillance. Refer to paediatric hepatology if ALT >2×ULN persists beyond 3 months."
      );
    }
  }

  if (cmf.hasCardiovascularDisease || cmf.hasT2Diabetes || cmf.hasHypertension || cmf.hasDyslipidemia) {
    monitoringPlan.push(
      "CV risk: calculate SCORE2 (or SCORE2-OP if age ≥70) annually. MASLD is classified as ≥moderate CV risk independent of other factors — treat accordingly. Refer to cardiologist if 10-year SCORE2 ≥10% or established CVD."
    );
  }

  // ── 12g. SPECIALIST REFERRAL ─────────────────────────────────────────────────
  let specialistReferral: string | null = null;
  if (hasCirchosis) {
    specialistReferral = "Hepatology (urgent) — cirrhosis management, HCC surveillance, portal hypertension, transplant evaluation";
  } else if (maddreysDF != null && maddreysDF >= 32) {
    specialistReferral = "Hepatology (urgent) — severe alcoholic hepatitis (Maddrey DF ≥32), prednisolone assessment and inpatient management";
  } else if (urgencyLevel === TreatmentPlanUrgencyLevel.urgent) {
    specialistReferral = "Hepatology — advanced fibrosis (FIB-4 >2.67 or F3-F4), liver biopsy and pharmacotherapy eligibility (resmetirom)";
  } else if (hasMASH && hasSignificantFibrosis) {
    specialistReferral = "Hepatology — MASH with significant fibrosis (F≥2), resmetirom candidacy assessment";
  } else if (sc.hasWilsonsDisease) {
    specialistReferral = "Hepatology / Metabolic — Wilson's disease, copper chelation therapy";
  } else if (sc.hasLipodystrophy) {
    specialistReferral = "Endocrinology / Metabolic Medicine — lipodystrophy, metreleptin therapy";
  } else if (sc.hasPcos) {
    specialistReferral = "Endocrinology / Gynaecology — PCOS, insulin sensitisation and androgen management";
  } else if (sc.hasCushingsSyndrome) {
    specialistReferral = "Endocrinology — Cushing's syndrome, cortisol excess workup and treatment";
  } else if (sc.hasTotalParenteralNutrition) {
    specialistReferral = "Intestinal Failure / Gastroenterology — IFALD, TPN optimisation and enteral transition";
  } else if (sldClassification === AssessmentResultsSldClassification.OtherSLD) {
    specialistReferral = "Hepatology — specific cause SLD (SC-SLD / DI-SLD), causality confirmation and primary cause treatment";
  } else if (bariatricSurgeryConsidered) {
    specialistReferral = "Bariatric/Metabolic Surgery — multidisciplinary evaluation for surgical weight management";
  } else if (cmf.hasT2Diabetes && urgencyLevel !== TreatmentPlanUrgencyLevel.routine) {
    specialistReferral = "Diabetology / Endocrinology — optimise GLP-1 RA or SGLT2i for T2D with MASLD";
  }

  // ── 12h. CLINICAL SUMMARY ────────────────────────────────────────────────────
  const classLabel =
    sldClassification === AssessmentResultsSldClassification.OtherSLD
      ? `SC-SLD/DI-SLD (${[...activeSecondaryCauses, ...activeDrugs].join(", ")})`
      : hasMASH
      ? "MASH"
      : sldClassification;

  const fibLabel = hasCirchosis
    ? "Cirrhosis (F4)"
    : hasSignificantFibrosis
    ? "Significant fibrosis (F≥2)"
    : fib4Risk === AssessmentResultsFib4Risk.low
    ? "Low fibrosis risk"
    : fib4Risk === AssessmentResultsFib4Risk.indeterminate
    ? "Indeterminate fibrosis risk — further imaging needed"
    : "Fibrosis risk unassessed";

  const leanNote = isLeanMasld ? " [Lean MASLD]" : "";
  const pediatricNote = isPediatric ? " [Paediatric — age-specific management]" : "";
  const maddrey = maddreysDF != null ? ` Maddrey DF: ${maddreysDF.toFixed(1)}${maddreysDF >= 32 ? " — SEVERE (prednisolone indication)" : ""}.` : "";
  const meld = meldScore != null ? ` MELD: ${meldScore}.` : "";
  const fast = fastScore != null ? ` FAST: ${fastScore.toFixed(3)}${fastScore >= 0.67 ? " (at-risk MASH)" : fastScore <= 0.35 ? " (at-risk MASH excluded)" : ""}.` : "";

  const summary = `${classLabel} with ${fibLabel}${leanNote}${pediatricNote}. FIB-4: ${fib4Score != null ? fib4Score.toFixed(2) : "unavailable"} (${fib4Risk} risk).${kpa != null ? ` Elastography: ${kpa} kPa (${elastographyRisk} risk).` : ""}${fast}${maddrey}${meld} Management priority: ${urgencyLevel}.`;

  const treatmentPlan: TreatmentPlan = {
    urgencyLevel,
    summary,
    lifestyleRecommendations,
    pharmacologicalOptions: [
      ...secondaryCauseRecommendations,
      ...diSldRecommendations,
      ...pharmacologicalOptions,
    ],
    monitoringPlan: [...comorbidityManagement, ...monitoringPlan],
    specialistReferral,
    bariatricSurgeryConsidered,
  };

  return {
    sldClassification,
    fib4Score,
    fib4Risk,
    fibrosisStage,
    elastographyRisk,
    fastScore,
    maddreysDF,
    meldScore,
    isLeanMasld,
    isPediatric,
    hasMASH,
    hasSignificantFibrosis,
    hasCirchosis,
    treatmentPlan,
  };
}
