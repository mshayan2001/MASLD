import { pgTable, serial, text, integer, numeric, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const assessmentsTable = pgTable("assessments", {
  id: serial("id").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  patientName: text("patient_name").notNull(),
  age: integer("age").notNull(),
  sex: text("sex").notNull(),
  ethnicity: text("ethnicity"),
  bmi: numeric("bmi", { precision: 5, scale: 2 }).notNull(),
  waistCircumferenceCm: numeric("waist_circumference_cm", { precision: 5, scale: 1 }),
  hasHepaticSteatosis: boolean("has_hepatic_steatosis").notNull(),
  alcoholGramsPerDay: numeric("alcohol_grams_per_day", { precision: 6, scale: 2 }).notNull(),
  notes: text("notes"),
  cardiometabolicFactors: jsonb("cardiometabolic_factors").notNull(),
  labValues: jsonb("lab_values").notNull(),
  imagingResults: jsonb("imaging_results").notNull(),
  secondaryCauses: jsonb("secondary_causes").notNull().default({}),
  hepatotoxicMedications: jsonb("hepatotoxic_medications").notNull().default({}),
  results: jsonb("results").notNull(),
});

export const insertAssessmentSchema = createInsertSchema(assessmentsTable).omit({ id: true, createdAt: true });
export type InsertAssessment = z.infer<typeof insertAssessmentSchema>;
export type Assessment = typeof assessmentsTable.$inferSelect;
